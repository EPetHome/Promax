---
name: requirement-clarifier
description: 诊断产品方案输入的完整性，区分阻塞性缺口与可默认缺口，生成最多 3 个关键澄清问题、默认处理和可追溯假设。在生成 PRD、流程、交互规格、HTML 原型或研发交接包前，当需求含糊、边界不明、关键决策缺失或需要不询问也能继续时使用。
---

# 需求澄清与默认兜底

## 目标

在不过度询问的前提下，阻止错误的范围、规则或验收标准进入后续产物。

## 工作流程

1. 读取需求、已知规则、约束、历史方案和验收要求。新项目优先从 `assets/product-solution-intake.yaml` 复制标准 intake，保留真实路径并删除空材料项。
2. 按 `references/clarification-schema.md` 检查目标、角色、范围、规则、数据、交互、安全、验收与交付。
3. 将缺口分为：
   - `blocking`：会改变核心范围、关键业务规则、高风险操作或验收标准。
   - `defaultable`：可以通过可逆假设继续，且不会造成不可接受的返工或风险。
   - `irrelevant`：对当前交付物无影响。
4. 仅从 `blocking` 中选择信息增益最高的 1–3 个问题。
5. 每个问题同时给出“不回答时默认为什么”和“默认会影响哪些产物”。
6. 将 `defaultable` 生成 `A-001` 开始的假设编号。

## 输出合同

```yaml
decision: proceed | clarification_required
questions:
  - id: Q-001
    question: 单一可回答问题
    why_blocking: 影响的核心决策
    fallback: 用户不回答时的默认处理
assumptions:
  - id: A-001
    statement: 默认假设
    impact: 影响范围
    reversible: true
known_constraints: []
```

## 规则

- 不问与当前交付物无关的问题。
- 不将产品名、作者、文档格式等可逆缺口当作阻塞项。
- 不用“请补充更多信息”这类无法直接回答的宽问题。
- 不将假设写成已确认事实。
- 后台子智能体将问题返回主智能体，不直接询问外部用户。

## 验证

- [ ] 问题数量不超过 3 个。
- [ ] 每个问题都会影响核心方案决策。
- [ ] 每个问题都有可执行的默认方案。
- [ ] 所有默认假设均有编号和影响说明。

## 埋点

仅当实际产出结构化澄清结果时，调用 `telemetry-tracker` 上报 `skill=requirement-clarifier`。埋点失败不阻断主任务。
