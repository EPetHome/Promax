import { afterEach, expect, it, vi } from "vitest";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import YAML from "yaml";
import { ContentObjectStore, LocalTrace } from "@promax/promax-report";
import { WorkStore, type WorkRound } from "../src/work-store.ts";
const judged = (round: WorkRound, state: "met" | "unmet" = "met") => ({ baseline_version: round.acceptance_baseline!.version, items: (round.acceptance_scope ?? []).map((id) => ({ id, state, evidence: "离线 fixture 当前版本逐项断言；不模拟模型判断" })) });
import { enforceDispatchPlanTool, memberToolDenial, coordinatorContext } from "../src/index.ts";
import { parseJudgeReport } from "../src/judge-report.ts";
import { renderCheckReport } from "../src/structured-results.ts";
import { deriveAgentStatus, emptyStatus, pendingResponseCount, registerFailure, resolveFaults, unprocessedEvents } from "../../promax-ui-console/src/work-control.ts";
import { requirementsDigest, type PendingItem } from "../../promax-ui-console/src/work-protocol.ts";
import { workRouteFixture } from "../../promax-ui-console/tests/work-route-fixture.ts";

let f: Awaited<ReturnType<typeof workRouteFixture>>;
afterEach(async () => {
  await f?.close();
});
const revision = {
  api_version: "promax.ai/v1alpha2",
  kind: "TeamRevision",
  metadata: { team_revision_id: "promax-product-team@r2", status: "published" },
  spec: {
    members: [
      { member_id: "product_discovery", display_name: "竞品分析师" },
      { member_id: "user_analysis", display_name: "数据分析师" },
      { member_id: "quality_judge", display_name: "检查" },
    ],
    artifacts: [
      { kind: "report", validation_kind: "report", relative_path: ".任务/{task_key}/产物快照/product_discovery.md", produced_by: "product_discovery" },
      { kind: "report", validation_kind: "report", relative_path: ".任务/{task_key}/产物快照/user_analysis.md", produced_by: "user_analysis" },
      { kind: "judge-report", validation_kind: "judge-report", relative_path: ".任务/{task_key}/判定-r{round}.md", produced_by: "quality_judge" },
    ],
  },
};
const FILES = ["product_discovery.md", "user_analysis.md"];
async function setup() {
  f = await workRouteFixture();
  await writeFile(join(process.env.DSH_HOME!, ".agent-presets/promax-team/team-revision.yml"), JSON.stringify(revision));
  const works = new WorkStore(f.scope.projectPath);
  const created = await f.request("work/card/update", { action: "create", sessionId: "session-one", title: "人员名单统计" });
  const card = ((await created.json()) as { card: { work_key: string; session_id: string } }).card;
  const events: Array<{ type: string; seq: number; data: Record<string, unknown> }> = [];
  let seq = 0;
  const main = () => ({ session: { header: { id: card.session_id, cwd: f.scope.projectPath }, events }, steer: stub });
  const steered: string[] = [];
  function stub(message: { content: Array<{ text: string }> }) {
    steered.push(message.content[0]!.text);
  }
  const payload = () => ({ agent: main(), turn: 1, signal: new AbortController().signal });
  const tick = (type: string, data: Record<string, unknown> = {}) => {
    events.push({ type, seq: ++seq, data });
    return seq;
  };
  const say = async (text: string, extra: Record<string, unknown> = {}) => {
    const response = await f.request("work/card/update", { work_key: card.work_key, action: "message", text, paths: [], ...extra });
    const body = (await response.json()) as { event: { id: string }; duplicate: boolean };
    tick("user/message", { content: [{ type: "text", text }], source: { kind: "user" } });
    return body;
  };
  let calls = 0;
  const propose = (args: Record<string, unknown>, callId = `p-${++calls}`) =>
    f.submit("promax_work_proposal", { card_patch: {}, deliverables: [], edit_request: null, handled_events: [], ...args }, { callId, agent: main() });
  const child = (id: string) => ({ session: { header: { id, cwd: f.scope.projectPath, origin: "subagent", parentSession: card.session_id }, events: [] } });
  const dispatch = async (member: string, childId: string, settle = true) => {
    tick("tool/call", { name: member, callId: `call-${childId}` });
    await f.hooks.get("tools/post-execute")!({ name: member, agent: main() }, { isError: false, value: { kind: "continuable", subagentId: childId } }, async () => ({}));
    if (settle) await f.hooks.get("subagent/end")!({ id: childId });
  };
  const stop = async () => {
    tick("assistant/message", { message: { content: [{ type: "text", text: "好的" }] } });
    await f.hooks.get("agent/turn-stopping")!(payload());
  };
  return { works, key: card.work_key, session: card.session_id, events, steered, say, propose, child, dispatch, stop, tick };
}
/** Saves real current versions for both outputs, as a finished earlier run would. */
async function publish(key: string, session: string, contents: Record<string, string>) {
  const works = new WorkStore(f.scope.projectPath);
  const objects = new ContentObjectStore(f.scope.projectPath);
  await mkdir(join(f.scope.projectPath, ".任务/baseline/产物快照"), { recursive: true });
  for (const [filename, content] of Object.entries(contents)) await writeFile(join(f.scope.projectPath, ".任务/baseline/产物快照", filename), content);
  const entries = objects.commit("baseline", new LocalTrace(f.scope.projectPath, session, "unit-test").id, Object.keys(contents).map((name) => `.任务/baseline/产物快照/${name}`), { workKey: key, kind: "ai_run", author: "personal" });
  const card = await works.read(key);
  card.deliverables = entries.map((e) => ({ filename: e.filename, member_id: e.filename.replace(".md", ""), current_sha256: e.current_sha256, status: "草稿 · 未检查" }));
  await writeFile(join(f.scope.projectPath, ".工作", key, "工作卡.yml"), YAML.stringify(card));
  return entries;
}
const question = (patch: Partial<PendingItem>): PendingItem => ({ id: "q", question: "问题？", source: "ai", ...patch });

it("GATE-CONTRACT-01 exposes the registered node contract and rejects actionable task-7 variants before commit", async () => {
  let w = await setup();
  const proposal = f.tools.get("promax_work_proposal")!;
  const schema = proposal.parameters as { properties: { card_patch: { properties?: Record<string, unknown> } } };
  const nodesSchema = schema.properties.card_patch.properties?.nodes as { items: { required: string[]; properties: { gate: { enum: readonly string[] }; filenames: { type: string }; depends_on: { type: string } } }; description: string };
  expect(nodesSchema.items.required).toEqual(["id", "title", "completion", "filenames", "gate"]);
  expect(nodesSchema.items.properties.gate.enum).toEqual(["employee", "checked_artifacts", "accepted_artifacts"]);
  expect(nodesSchema.items.properties.filenames.type).toBe("array");
  expect(nodesSchema.items.properties.depends_on.type).toBe("array");
  expect(nodesSchema.description).toContain("必须关联至少一份成果");
  expect(schema.properties.card_patch).not.toHaveProperty("additionalProperties", false);
  let input = await w.say("分析附件并出一份报告");
  const events = () => [{ event_id: input.event.id, intent: "new_task", impact: "normal", note: "按委托分析", affects: [] }];
  const node = { id: "n1", title: "核对评分口径", completion: "明确有效记录", filenames: [] as string[], gate: "employee" as unknown };
  const other = { id: "n2", title: "形成报告", completion: "交付报告", filenames: ["user_analysis.md"], gate: "checked_artifacts" as unknown };
  const submit = (nodes: unknown, callId: string) => w.propose({ intent: "execute", deliverables: ["user_analysis.md"], card_patch: { nodes }, handled_events: events() }, callId);
  for (const [bad, paths, actual] of [
    [[{ ...node, gate: undefined }, other], ["nodes[0].gate"], "缺失"],
    [[{ ...node, gate: { checked_artifacts: [] } }, other], ["nodes[0].gate"], "object"],
    [[node, { ...other, gate: null }], ["nodes[1].gate"], "null"],
    [[{ ...node, gate: "checked_artifacts" }, { ...other, gate: null }], ["nodes[0].filenames", "nodes[1].gate"], "null"],
    [[{ ...node, gate: "made_up", filenames: ["outside.md"] }, other], ["nodes[0].gate", "nodes[0].filenames[0]"], "made_up"],
    [[{ ...node, filenames: null }, other], ["nodes[0].filenames"], "null"],
  ] as const) {
    const failed = await submit(bad, `gate-bad-${actual}-${paths.join("-")}`);
    expect(failed.isError).toBe(true);
    for (const path of paths) expect(String(failed.value)).toContain(`card_patch.${path}`);
    expect(String(failed.value)).toContain(actual);
    const repaired = (bad as readonly Record<string, unknown>[]).map((item, index) => ({ ...item,
      ...((paths as readonly string[]).includes(`nodes[${index}].gate`) ? { gate: index === 0 ? "employee" : "checked_artifacts" } : {}),
      ...(paths.some((p) => p.startsWith(`nodes[${index}].filenames`)) ? { filenames: index === 0 && item.gate !== "checked_artifacts" ? [] : ["user_analysis.md"] } : {}),
    }));
    const fixed = await submit(repaired, `gate-fixed-${actual}-${paths.join("-")}`);
    expect(fixed.isError, String(fixed.value)).toBe(false);
    expect((await w.works.round(w.key))?.turn.card_patch.nodes).toMatchObject(repaired);
    await f.close();
    w = await setup();
    input = await w.say("分析附件并出一份报告");
  }
  const fixed = await submit([node, other], "gate-fixed");
  expect(fixed.isError, String(fixed.value)).toBe(false);
  expect((await w.works.round(w.key))?.turn.card_patch.nodes).toMatchObject([node, other]);
});

it("GATE-CONTRACT-01 answer retains other legal card_patch fields without nodes or new dispatch", async () => {
  const w = await setup();
  const input = await w.say("这份材料有哪些限制？");
  const reply = await w.propose({ intent: "answer", card_patch: { pending: [{ id: "clarify", question: "范围是否仅限本次材料？" }], side_topic: { text: "后续样本", reason: "本次之外" } }, handled_events: [{ event_id: input.event.id, intent: "question", impact: "normal", note: "先解释材料限制" }] });
  expect(reply.isError, String(reply.value)).toBe(false);
  const card = await w.works.read(w.key);
  expect(card.pending.map((p) => p.id)).toContain("clarify");
  expect(card.side_topics?.[0]?.text).toBe("后续样本");
  expect(card.spine?.nodes ?? []).toHaveLength(0);
  expect((await w.works.round(w.key))?.task_key).toBeFalsy();
  expect(card.events?.find((e) => e.id === input.event.id)?.state).toBe("answered");
});

it("GATE-CONTRACT-01 keeps valid dependency and scope fields at the registered proposal entry", async () => {
  const w = await setup();
  const input = await w.say("先梳理材料再做分析报告");
  const first = { id: "intake", title: "核对材料", completion: "确认范围", filenames: [] as string[], gate: "employee" };
  const report = { id: "report", title: "形成报告", completion: "成果检查", filenames: ["user_analysis.md"], gate: "checked_artifacts", depends_on: ["intake"] };
  const proposed = await w.propose({ intent: "guide", card_patch: { nodes: [first, report] }, handled_events: [{ event_id: input.event.id, intent: "new_task", impact: "normal", note: "梳理材料再交报告" }] });
  expect(proposed.isError, String(proposed.value)).toBe(false);
  const initial = await w.works.read(w.key);
  expect(initial.spine?.nodes.find((n) => n.id === "report")?.depends_on, JSON.stringify({ spine: initial.spine, faults: (await w.works.status(w.key)).faults })).toEqual(["intake"]);
  const update = await w.say("将材料核对归入报告阶段");
  const changed = await w.propose({ intent: "guide", card_patch: { goal: "范围缩小", nodes: [{ ...report, depends_on: [] }], scope_change_reason: "员工提出范围变化", scope_moves: [{ node_id: "intake", action: "merge", target_node_id: "report", reason: "原条件迁入" }] }, handled_events: [{ event_id: update.event.id, intent: "supplement", impact: "normal", note: "请求合并阶段" }] });
  expect(changed.isError, String(changed.value)).toBe(false);
  const card = await w.works.read(w.key);
  expect(card.scope_proposal).toMatchObject({ reason: "员工提出范围变化", moves: [{ node_id: "intake", action: "merge", target_node_id: "report" }] });
  expect(card.spine?.nodes.map((n) => n.id)).toEqual(["intake", "report"]); // No implicit removal before employee decision.
});

it("T1 successful authorized write exposes an immutable draft while its member is running; failed/empty writes do not", async () => {
  const w = await setup();
  const received = await w.say("做竞品调研");
  await w.propose({ intent: "execute", deliverables: ["product_discovery.md"], handled_events: [{ event_id: received.event.id, intent: "new_task", impact: "normal", note: "开始" }] });
  const proposed = (await w.works.round(w.key))!;
  await f.request("work/card/update", { work_key: w.key, action: "start", revision: proposed.revision, source: "click" });
  await w.dispatch("product_discovery", "draft-worker", false);
  const run = (await w.works.round(w.key))!, filename = "product_discovery.md";
  const path = join(f.scope.projectPath, ".任务", run.task_key!, "产物快照", filename);
  const wrote = (isError = false, name = "write") => f.hooks.get("tools/post-execute")!({ name, arguments: { path }, callId: `draft-${name}`, agent: w.child("draft-worker") }, { isError }, async () => ({}));
  await writeFile(path, "# 标题"); await wrote();
  expect((await w.works.read(w.key)).deliverables[0]!.draft).toBeUndefined();
  await writeFile(path, "# 竞品\n第一份正文"); await wrote(true);
  expect((await w.works.read(w.key)).deliverables[0]!.draft).toBeUndefined();
  await wrote();
  const draft = (await w.works.read(w.key)).deliverables[0]!.draft!;
  expect(draft.task_key).toBe(run.task_key);
  expect((await w.works.round(w.key))!.phase ?? "generating").toBe("generating");
  expect((await w.works.read(w.key)).deliverables[0]!.current_sha256).toBeNull();
  await wrote(); expect((await w.works.read(w.key)).deliverables[0]!.draft).toEqual(draft);
  const sourcePath = `.任务/${run.task_key}/输入/evidence.json`;
  await writeFile(join(f.scope.projectPath, sourcePath), "[]");
  const { createHash } = await import("node:crypto");
  const handoff = { available: ["冻结样本0条，比例不可测"], sources: [{ path: sourcePath, sha256: createHash("sha256").update("[]").digest("hex"), range: "全部记录" }], scope: "仅本批样本", needed_by: ["客户研究：用户证据仍缺失，仅保留假设"], gaps: ["实际用户证据"] };
  const receipt = { filename, status: "draft_ready", summary: "部分资料可用", unverified: [], gaps: [], input_version: run.execution_version, handoff };
  expect((await f.submit("promax_member_receipt", { ...receipt, handoff: { ...handoff, sources: [{ ...handoff.sources[0], sha256: "0".repeat(64) }] } }, { callId: "bad-handoff", agent: w.child("draft-worker") })).isError).toBe(true);
  expect((await f.submit("promax_member_receipt", receipt, { callId: "ready-handoff", agent: w.child("draft-worker") })).isError).toBe(false);
  expect((await w.works.observations(w.key)).find((e) => e.kind === "information_ready")).toMatchObject({ handoff });
  const read = await f.request("artifact/read-draft", { work_key: w.key, filename, version_sha256: draft.sha256 });
  expect(read.status).toBe(200); expect((await read.json()).content).toContain("第一份正文");
  expect((await f.request("artifact/draft-actionable", { work_key: w.key, filename, version_sha256: draft.sha256, client_at: new Date().toISOString() })).status).toBe(200);
  await writeFile(path, "# 竞品\n脚本更新的正文"); await wrote(false, "bash");
  const next = (await w.works.read(w.key)).deliverables[0]!.draft!;
  expect(next.sha256).not.toBe(draft.sha256); expect(next.first_readable_at).toBe(draft.first_readable_at);
  await w.works.writeRound(w.key, { ...run, phase: "ended" });
  expect((await new WorkStore(f.scope.projectPath).readDraft(w.key, filename, next.sha256)).content).toContain("脚本更新");
  await f.hooks.get("subagent/end")!({ id: "draft-worker", stopReason: "cancelled" });
  expect(new ContentObjectStore(f.scope.projectPath).index().artifacts).toHaveLength(0);
});

it("T1 attachment + original task, then “采纳”:  the frozen run input keeps the whole task and a stable, traceable source id", async () => {
  const w = await setup();
  const roster = "# 安装登记花名册\n| # | 姓名 |\n| 1 | 甲 |\n";
  const uploaded = await f.request("attachments", { sessionId: w.session, files: [{ name: "花名册.md", contentBase64: Buffer.from(roster).toString("base64") }] });
  const { paths } = (await uploaded.json()) as { paths: string[] };
  await w.say("我需要做一个统计人员名单的系统，先做用户调研", { paths });
  await w.propose({ intent: "guide", card_patch: { goal: "为人员名单统计系统做用户调研", suggestions: [{ text: "访谈检查人、登记人、管理者各 1 人", basis: "材料分工" }] } });
  await w.say("采纳", { suggestion_target: "访谈检查人、登记人、管理者各 1 人" });
  const reply = await w.propose({ intent: "execute", deliverables: ["user_analysis.md"], handled_events: [] });
  expect(reply.isError, String(reply.value)).toBe(false);
  const card = await w.works.read(w.key);
  expect(card.origin?.text).toContain("统计人员名单的系统");
  expect(card.suggestions?.[0]).toMatchObject({ state: "accepted" });
  expect(card.events?.at(-1)).toMatchObject({ text: "采纳", state: "applied", note: expect.stringContaining("不代表已执行") });
  const round = (await w.works.round(w.key))!;
  const started = await f.request("work/card/update", { work_key: w.key, action: "start", revision: round.revision, source: "click" });
  expect(started.status, await started.clone().text()).toBe(200);
  const task = (await w.works.round(w.key))!.task_key!;
  expect(task).not.toBe("采纳");
  const manifest = YAML.parse(await readFile(join(f.scope.projectPath, ".任务", task, "输入/manifest.yml"), "utf8"));
  const material = manifest.inputs.src_files.find((s: { original_filename: string }) => s.original_filename === "花名册.md");
  expect(material).toMatchObject({ source_id: "SRC-001", sha256: card.materials[0]!.sha256 });
  const demand = manifest.spec.sources.at(-1);
  const frozen = await readFile(join(f.scope.projectPath, demand.relative_path), "utf8");
  expect(frozen).toContain("## 原始任务\n我需要做一个统计人员名单的系统，先做用户调研");
  expect(frozen).toContain("## 本轮最新输入（增量，不替代原始任务）\n采纳");
  expect(frozen).toContain("访谈检查人、登记人、管理者各 1 人（建议版本");
  expect(frozen).toContain("不代表已经执行");
  expect(frozen).toContain("- 花名册.md");
  // The derived card summary is never frozen as an independent source.
  expect(manifest.spec.sources).toHaveLength(2);
});

it("T2 business replies with two outputs enter follow-up; a counter-question and a bare yes never become decisions; a revision is not co-effective", async () => {
  const w = await setup();
  await w.say("先调研");
  await publish(w.key, w.session, { "product_discovery.md": "# 探索\n## 识别口径\n待定\n", "user_analysis.md": "# 用户\n## 识别口径\n待定\n" });
  const card = await w.works.read(w.key);
  card.pending = [
    question({ id: "identity", question: "同一个人最终按什么识别？", decision_key: "identity_key", options: ["部门+姓名", "工号/手机号等唯一标识"] }),
    question({ id: "source", question: "市场调研缺少一手来源，本轮怎么处理？", options: ["先交付并标注待核验", "等来源补齐"] }),
    question({ id: "nexus", question: "nexus 是完全不做，还是本次调研先不涉及？", options: ["完全不做", "本次先不涉及"] }),
  ];
  await writeFile(join(f.scope.projectPath, ".工作", w.key, "工作卡.yml"), YAML.stringify(card));
  const decide = async (id: string, text: string, event_id: string) => (await (await f.request("work/card/update", { work_key: w.key, action: "decide", id, text, event_id, base_updated_at: (await w.works.read(w.key)).updated_at })).json()) as Record<string, unknown>;
  expect(await decide("identity", "工号", "e-id")).toMatchObject({ needs_context: true, guard: "ok" });
  expect(await decide("source", "是空白还是什么原因", "e-why")).toMatchObject({ guard: "question" });
  expect(await decide("nexus", "是的", "e-yes")).toMatchObject({ guard: "ambiguous" });
  let read = await w.works.read(w.key);
  expect(read.decisions ?? []).toEqual([]);
  expect(pendingResponseCount(read)).toBe(3); // Replies are received, but none is understood as enough yet.
  const reply = await w.propose({
    intent: "answer",
    handled_events: [
      { event_id: "e-id", intent: "decision", impact: "normal", question_id: "identity", answer: "工号", affects: FILES, note: "识别口径改为工号，两份成果局部更新" },
      { event_id: "e-why", intent: "decision", impact: "normal", question_id: "source", answer: "是空白还是什么原因", affects: [], note: "说明缺来源的原因" },
      { event_id: "e-yes", intent: "decision", impact: "normal", question_id: "nexus", answer: "是的", affects: [], clarify: "你是指完全不做，还是本次先不涉及？", note: "需要确认选哪一项" },
    ],
  });
  expect(reply.isError, String(reply.value)).toBe(false);
  read = await w.works.read(w.key);
  expect(read.decisions).toMatchObject([{ id: "identity", answer: "工号", affects: FILES }]);
  expect(read.events?.find((e) => e.id === "e-id")?.state).toBe("pending_apply");
  expect(read.events?.find((e) => e.id === "e-why")).toMatchObject({ state: "answered", intent: "question" });
  expect(read.events?.find((e) => e.id === "e-yes")?.state).toBe("clarifying");
  expect(read.pending.map((p) => p.id)).toEqual(expect.arrayContaining(["source", "nexus"]));
  // With saved outputs the program arranges a local revision of both files instead of recording "no change".
  const round = (await w.works.round(w.key))!;
  expect(round.turn).toMatchObject({ intent: "execute", deliverables: FILES });
  expect(round.revise?.instruction).toContain("工号");
  expect(read.decisions![0]!.state).toBe("awaiting_start");
  // A fabricated answer that is not in the employee's words is refused with a concrete reason.
  const fabricated = await w.propose({ intent: "answer", handled_events: [{ event_id: "e-yes", intent: "decision", impact: "normal", question_id: "nexus", answer: "完全不做", note: "x" }] });
  expect(fabricated).toMatchObject({ isError: true, value: expect.stringContaining("必须来自员工原话或所选选项") });
  // A later answer to the same business decision supersedes the old one; only one is effective.
  read = await w.works.read(w.key);
  read.pending.push(question({ id: "identity-2", question: "同一个人最终按什么识别（重新确认）？", decision_key: "identity_key", options: ["工号", "部门+姓名"] }));
  await writeFile(join(f.scope.projectPath, ".工作", w.key, "工作卡.yml"), YAML.stringify(read));
  await decide("identity-2", "部门+姓名", "e-id2");
  read = await w.works.read(w.key);
  expect(read.decisions?.filter((d) => d.state !== "superseded" && d.state !== "withdrawn").map((d) => d.answer)).toEqual(["部门+姓名"]);
  expect(read.decisions?.find((d) => d.answer === "工号")).toMatchObject({ state: "superseded" });
  expect(read.confirmed.filter((c) => c.source === "decision").map((c) => c.text)).toEqual([expect.stringContaining("部门+姓名")]);
  expect(requirementsDigest(read)).not.toContain("工号");
});

it("T3/T4 a high-impact correction pauses only the affected output; earlier normal inputs still get handled; stale results never become current; restart resumes", async () => {
  const w = await setup();
  await w.say("两份调研都要");
  const proposed = await w.propose({ intent: "execute", deliverables: FILES, handled_events: [{ event_id: (await w.works.read(w.key)).events![0]!.id, intent: "new_task", impact: "normal", note: "开始两份调研" }] });
  expect(proposed.isError, String(proposed.value)).toBe(false);
  const round0 = (await w.works.round(w.key))!;
  expect((await f.request("work/card/update", { work_key: w.key, action: "start", revision: round0.revision, source: "countdown" })).status).toBe(200);
  const version = (await w.works.round(w.key))!.execution_version!;
  await w.dispatch("product_discovery", "pd-1", false);
  await w.dispatch("user_analysis", "ua-1", false);
  const task = (await w.works.round(w.key))!.task_key!;
  for (const file of FILES) await writeFile(join(f.scope.projectPath, ".任务", task, "产物快照", file), `# ${file}\n旧口径草稿\n`);
  // Two inputs while running: a normal supplement first, then a high-impact correction.
  const normal = await w.say("补充：统计维度加上部门");
  const urgent = await w.say("不对，用户分析不要按姓名统计");
  let card = await w.works.read(w.key);
  expect(unprocessedEvents(card).map((e) => e.id)).toEqual([normal.event.id, urgent.event.id]);
  // Members settle; before anything is dispatched again or committed, the coordinator must understand those inputs.
  f.hooks.get("subagent/end")!({ id: "pd-1" });
  f.hooks.get("subagent/end")!({ id: "ua-1" });
  await w.stop();
  expect(w.steered.at(-1)).toContain(urgent.event.id);
  expect((await w.works.round(w.key))!.phase ?? "generating").toBe("generating");
  const understood = await w.propose({ intent: "answer", handled_events: [{ event_id: urgent.event.id, intent: "correction", impact: "high", affects: ["user_analysis.md"], note: "用户分析改口径，暂停该成果" }] });
  expect(understood.isError, String(understood.value)).toBe(false);
  card = await w.works.read(w.key);
  // The high-priority input was processed first; the earlier normal input keeps its own pending record.
  expect(unprocessedEvents(card).map((e) => e.id)).toEqual([normal.event.id]);
  expect((await w.works.status(w.key)).alignments).toMatchObject([{ state: "active", affects: ["user_analysis.md"] }]);
  // Waiting for the coordinator to understand inputs consumed no recovery budget.
  expect((await w.works.status(w.key)).faults).toEqual([]);
  expect(deriveAgentStatus(card, await w.works.round(w.key), await w.works.status(w.key)).steps.find((s) => s.id === "file:user_analysis.md")?.control).toBe("aligning");
  await w.propose({ intent: "answer", handled_events: [{ event_id: normal.event.id, intent: "supplement", impact: "normal", affects: [], note: "维度加部门，已记录" }] });
  expect(unprocessedEvents(await w.works.read(w.key))).toEqual([]);
  // The unaffected member submits its receipt; a receipt for the paused output does not advance it.
  const receipt = (filename: string) => ({ filename, status: "draft_ready", summary: "完成", unverified: [], gaps: [], input_version: version });
  expect((await f.submit("promax_member_receipt", receipt("product_discovery.md"), { callId: "r-pd", agent: w.child("pd-1") })).isError).toBe(false);
  // Restart: a fresh store and fresh hook state continue from persisted receipts.
  const restarted = new WorkStore(f.scope.projectPath);
  expect((await restarted.round(w.key))!.receipts?.["product_discovery.md"]).toMatchObject({ member: "product_discovery" });
  await w.stop();
  // New protocol: changed requirements end the old execution as partial; do not invite a stale PASS.
  expect((await w.works.read(w.key)).last_progress).toContain("部分完成");
  const ended = (await w.works.round(w.key))!;
  const objects = new ContentObjectStore(f.scope.projectPath).index().artifacts;
  expect(objects.map((a) => a.filename)).toEqual(["product_discovery.md"]);
  // The stale draft stays as a draft; only the affected output is proposed again under the new version.
  expect(ended).toMatchObject({ source: "proposal", turn: { intent: "execute", deliverables: ["user_analysis.md"] } });
  expect(await readFile(join(f.scope.projectPath, ".任务", task, "产物快照/user_analysis.md"), "utf8")).toContain("旧口径草稿");
  expect(ended.last_check?.verdict).not.toBe("PASS");
});

it("T5 structured entries accept legal results, reject missing fields/illegal values/wrong versions, dedupe receipts, and render a parseable report; the old quoting failure no longer ends work", async () => {
  const w = await setup();
  await w.say("做竞品调研");
  expect(await w.propose({ intent: "maybe" })).toMatchObject({ isError: true, value: expect.stringContaining("intent 只能是") });
  expect((await f.submit("promax_work_proposal", { intent: "answer", card_patch: {}, deliverables: [], edit_request: null }, { callId: "no-events", agent: { session: { header: { id: w.session, cwd: f.scope.projectPath }, events: [] } } })).value).toContain("handled_events 必填");
  const nodes = [{ id: "research", title: "调研", completion: "成果完成", filenames: ["product_discovery.md"], gate: "checked_artifacts" }, { id: "broken", title: "缺少完成" }];
  expect(await w.propose({ intent: "guide", card_patch: { nodes } })).toMatchObject({ isError: true, value: expect.stringContaining("card_patch.nodes[1].completion 实际 缺失") });
  const faults = (await w.works.status(w.key)).faults.find((x) => x.step === "coordinator");
  expect(faults?.attempts).toBe(3);
  const accepted = await w.propose({ intent: "execute", deliverables: ["product_discovery.md"], card_patch: { nodes: [nodes[0]] }, handled_events: [{ event_id: (await w.works.read(w.key)).events![0]!.id, intent: "new_task", impact: "normal", note: "开始竞品调研" }] });
  expect(accepted.isError, String(accepted.value)).toBe(false);
  expect((await w.works.read(w.key)).spine?.nodes.map((n) => n.id)).toEqual(["research"]);
  expect((await w.works.status(w.key)).faults.find((x) => x.step === "coordinator")?.state).toBe("resolved");
  const round0 = (await w.works.round(w.key))!;
  await f.request("work/card/update", { work_key: w.key, action: "start", revision: round0.revision, source: "click" });
  const round = (await w.works.round(w.key))!;
  await w.dispatch("product_discovery", "pd-1");
  const receipt = { filename: "product_discovery.md", status: "draft_ready", summary: "完成", unverified: [], gaps: [], input_version: round.execution_version };
  expect((await f.submit("promax_member_receipt", receipt, { callId: "early", agent: w.child("pd-1") })).value).toContain("尚未落盘");
  await writeFile(join(f.scope.projectPath, ".任务", round.task_key!, "产物快照/product_discovery.md"), "# 竞品\n");
  expect((await f.submit("promax_member_receipt", { ...receipt, filename: "user_analysis.md" }, { callId: "other", agent: w.child("pd-1") })).value).toContain("filename 必须是你本轮负责的成果");
  expect((await f.submit("promax_member_receipt", { ...receipt, input_version: 0 }, { callId: "stale", agent: w.child("pd-1") })).value).toContain("input_version");
  expect((await f.submit("promax_member_receipt", receipt, { callId: "ok", agent: w.child("pd-1") })).isError).toBe(false);
  const beforeRetry = await w.works.round(w.key);
  expect((await f.submit("promax_member_receipt", receipt, { callId: "again", agent: w.child("pd-1") })).isError).toBe(false);
  // stage only validates; authoritative commit owns deduplication (R12). No history/status rewrite.
  expect(await w.works.round(w.key)).toEqual(beforeRetry);
  expect((await f.submit("promax_member_receipt", receipt, { callId: "stranger", agent: w.child("unbound") })).isError).toBe(true);
  await w.stop();
  const checking = (await w.works.round(w.key))!;
  expect(checking.phase).toBe("checking");
  // The same kind of content that broke the hand-written YAML header is plain data here.
  await w.dispatch("quality_judge", "judge-1");
  const quoted = { id: "D1", question: "口径怎么定？", options: ["A", "B"], location: "3.1", evidence: "原文", current_content: '| B4 | 输入"晏小红🎈"（E-05） | 在名单里 |' };
  const issue = { id: "PD-01", severity: "medium", artifact: "product_discovery.md", location: "3.1 口径说明", evidence: '第 111 行写「部门信息只出现在 6 条"待登记"记录」', impact: "计数不一致", fix: "统一口径" };
  expect((await f.submit("promax_check_result", { verdict: "REVISION_REQUIRED", issues: [{ ...issue, owner_member_id: "user_analysis" }], unverified: [], decisions: [quoted], input_version: checking.execution_version, review_request: checking.review_request }, { callId: "bad-owner", agent: w.child("judge-1") })).value).toContain("登记责任成员");
  const good = await f.submit("promax_check_result", { verdict: "REVISION_REQUIRED", acceptance: judged(checking, "unmet"), issues: [issue], unverified: [], decisions: [quoted], input_version: checking.execution_version, review_request: checking.review_request }, { callId: "good", agent: w.child("judge-1") });
  expect(good.isError, String(good.value)).toBe(false);
  const report = await readFile(join(f.scope.projectPath, ".任务", checking.task_key!, "判定-r1.md"), "utf8");
  expect(parseJudgeReport(report, { hashes: checking.reviewed_hashes!, scope: "", round: 1 }).report?.decisions[0]?.current_content).toBe(quoted.current_content);
  expect(renderCheckReport((await w.works.round(w.key))!.check_results!["1"]!)).toBe(report);
  // Legacy compatibility: the real failure pattern (unescaped quotes) is unreadable, and in a historical round it recovers instead of finishing.
  const legacy = `---\nreviewer: quality_judge\nround: 1\nverdict: PASS\nscope: s\nreviewed_artifacts:\n  - filename: a.md\n    sha256: ${"a".repeat(64)}\nissues: []\nunverified: []\ndecisions:\n  - id: D1\n    question: q\n    current_content: "| B4 | 输入"晏小红"（E-05） |"\n---\n`;
  expect(parseJudgeReport(legacy).error).toContain("YAML");
  await w.stop();
  expect((await w.works.round(w.key))!.phase).toBe("checking"); // Judge no longer assigns the repair.
  const planned = await f.submit("promax_repair_plan", { judge_round: 1, assignments: [{ member: "product_discovery", files: ["product_discovery.md"], issue_ids: ["PD-01"], instruction: "统一可核实的计数口径" }] }, { callId: "repair-plan", agent: { session: { header: { id: w.session, cwd: f.scope.projectPath }, events: w.events } } });
  expect(planned.isError, String(planned.value)).toBe(false);
  expect((await w.works.round(w.key))!).toMatchObject({ phase: "repairing", repair_round: 1 });
});

it("T7 duty/phase authorization admits retrieval, skills and structured submission, and still refuses sibling dispatch, cross-role submission and foreign write paths", async () => {
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "web_search")).toBeUndefined();
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "web_fetch")).toBeUndefined();
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "skill")).toBeUndefined();
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "promax_member_receipt")).toBeUndefined();
  expect(memberToolDenial("solution_design", { phase: "generating", protocol: 2 }, "web_search")).toBeUndefined();
  expect(memberToolDenial("solution_design", { phase: "generating", protocol: 2 }, "ask_user_question")).toContain("直接询问员工");
  expect(memberToolDenial("solution_design", { phase: "generating", protocol: 2 }, "some_unlisted_tool")).toContain("不在方案设计师当前阶段的许可范围内");
  expect(memberToolDenial("product_discovery", { phase: "checking", protocol: 2 }, "promax_member_receipt")).toContain("检查阶段");
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "user_analysis")).toContain("同级成员");
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "promax_check_result")).toContain("独立检查");
  expect(memberToolDenial("product_discovery", { phase: "generating", protocol: 2 }, "promax_work_proposal")).toContain("主 Agent");
  expect(memberToolDenial("quality_judge", { phase: "checking", protocol: 2 }, "promax_check_result")).toBeUndefined();
  expect(memberToolDenial("quality_judge", { phase: "checking", protocol: 2 }, "write")).toContain("promax_check_result");
  expect(memberToolDenial("quality_judge", { phase: "checking", protocol: 2 }, "web_search")).toContain("独立检查只允许");
  const w = await setup();
  await w.say("做竞品调研");
  await w.propose({ intent: "execute", deliverables: ["product_discovery.md"], handled_events: [{ event_id: (await w.works.read(w.key)).events![0]!.id, intent: "new_task", impact: "normal", note: "开始" }] });
  await f.request("work/card/update", { work_key: w.key, action: "start", revision: (await w.works.round(w.key))!.revision, source: "click" });
  const task = (await w.works.round(w.key))!.task_key!;
  await w.dispatch("product_discovery", "pd-1");
  const allow = async () => "allow";
  expect(await enforceDispatchPlanTool(f.root, { name: "web_search", arguments: { query: "名单工具" }, agent: w.child("pd-1") }, allow)).toBe("allow");
  expect(await enforceDispatchPlanTool(f.root, { name: "skill", arguments: { name: "search-engine" }, agent: w.child("pd-1") }, allow)).toBe("allow");
  expect(await enforceDispatchPlanTool(f.root, { name: "write", arguments: { path: `.任务/${task}/产物快照/product_discovery.md` }, agent: w.child("pd-1") }, allow)).toBe("allow");
  expect(await enforceDispatchPlanTool(f.root, { name: "write", arguments: { path: `.任务/${task}/产物快照/user_analysis.md` }, agent: w.child("pd-1") }, allow)).toMatchObject({ kind: "deny" });
  expect(await enforceDispatchPlanTool(f.root, { name: "send_message", arguments: {}, agent: w.child("pd-1") }, allow)).toMatchObject({ kind: "deny" });
  // The coordinator in discussion may submit its proposal but never member receipts.
  expect(await enforceDispatchPlanTool(f.root, { name: "promax_member_receipt", agent: { session: { header: { id: w.session, cwd: f.scope.projectPath } } } }, allow)).toMatchObject({ kind: "deny" });
});

it("T6/T11 unresolved faults stay listed with first time and count; inputs survive exhaustion; usage is recorded only as reported; code-only operations never steer the model", async () => {
  const w = await setup();
  const first = await w.say("帮我看看");
  await w.stop(); // no structured proposal: recovery 1
  expect(w.steered.at(-1)).toContain(first.event.id);
  // A different session event or wording is the same fault: the budget is not reset.
  w.tick("assistant/message", { message: { content: [] }, usage: { inputTokens: 120, outputTokens: 30 } });
  await f.hooks.get("agent/turn-stopping")!({ agent: { session: { header: { id: w.session, cwd: f.scope.projectPath }, events: w.events }, steer: () => {} }, turn: 2, signal: new AbortController().signal });
  let status = await w.works.status(w.key);
  expect(status.faults.find((x) => x.step === "coordinator")).toMatchObject({ attempts: 2, state: "recovering" });
  expect(status.usage).toEqual([expect.objectContaining({ input_tokens: 120, output_tokens: 30, kind: "turn" })]);
  // The first input was attempted twice; it is kept and visibly failed instead of silently dropped.
  await w.stop();
  let card = await w.works.read(w.key);
  expect(card.events?.find((e) => e.id === first.event.id)).toMatchObject({ state: "failed", text: "帮我看看" });
  // A second, independent fault on another step is kept alongside.
  await w.works.noteFailure(w.key, { step: "check", class: "check_output_invalid", evidence: "x", reason: "检查结果缺字段", strategy: "重试", at: new Date(Date.now() + 1000).toISOString() });
  await w.works.noteFailure(w.key, { step: "check", class: "check_output_invalid", evidence: "y", reason: "检查结果缺字段", strategy: "重试", at: new Date(Date.now() + 2000).toISOString() });
  status = await w.works.status(w.key);
  card = await w.works.read(w.key);
  const view = deriveAgentStatus(card, await w.works.round(w.key), status);
  expect(view.faults.map((x) => x.step).sort()).toEqual(["check", "coordinator"]);
  expect(view.recent_error).toContain("同类 2 次");
  expect(view.recent_error).toContain(status.faults.find((x) => x.step === "check")!.first_at);
  // Reading work, navigating and saving drafts are code operations: no steer, no round change.
  const before = w.steered.length;
  const roundBefore = await w.works.round(w.key);
  await f.request("work/read", { work_key: w.key });
  await f.request("work/card/update", { work_key: w.key, action: "interact", drafts: { "answer:x": "未提交" } });
  expect(w.steered.length).toBe(before);
  expect(await w.works.round(w.key)).toEqual(roundBefore);
  const read = (await (await f.request("work/read", { work_key: w.key })).json()) as { status: { faults: unknown[]; unprocessed: unknown[] } };
  expect(read.status.faults).toHaveLength(2);
  expect(coordinatorContext(card, roundBefore, view, [])).toContain("Agent Status");
});

it("T6 a paused fault stays paused on the same version (restart or new session cannot reset it), resumes with a fresh budget only under a different runtime version, and an actual success clears it", () => {
  const status = emptyStatus();
  const fail = (evidence: string, runtime_version: string) =>
    registerFailure(status, { step: "check", class: "check_output_invalid", evidence, reason: `缺字段 ${evidence}`, strategy: "重试", at: `2026-09-15T00:00:0${evidence.length % 10}.000Z`, runtime_version });
  expect(["a", "bb", "ccc"].map((e) => fail(e, "0.1.63").decision)).toEqual(["retry", "retry", "retry"]);
  expect(fail("dddd", "0.1.63")).toMatchObject({ decision: "exhausted", fault: { state: "needs_fix", attempts: 4 } });
  // Same version after a process restart or another child session: still paused, no new attempts granted.
  expect(fail("eeeee", "0.1.63")).toMatchObject({ decision: "exhausted", fault: { attempts: 5 } });
  expect(status.faults.filter((f) => f.state !== "resolved")).toHaveLength(1);
  // A different runtime version (the fix actually deployed) starts a fresh budget; the paused record is kept as history.
  expect(fail("ffffff", "0.1.64")).toMatchObject({ decision: "retry", fault: { attempts: 1, runtime_version: "0.1.64" } });
  expect(status.faults.map((f) => f.state)).toEqual(["resolved", "recovering"]);
  expect(status.faults[0]!.history).toHaveLength(5);
  // An authoritative success closes even a paused fault.
  fail("g", "0.1.64"); fail("hh", "0.1.64"); fail("iii", "0.1.64");
  expect(status.faults[1]!.state).toBe("needs_fix");
  expect(resolveFaults(status, "check", "2026-09-15T01:00:00.000Z")).toBe(true);
  expect(status.faults.every((f) => f.state === "resolved")).toBe(true);
});

it("T5/T7 actual dispatch and continuation: three version-bound reviews share one Judge, coordinator repairs, no false undispatched recovery", async () => {
  const w = await setup();
  const received = await w.say("做竞品调研");
  await w.propose({ intent: "execute", deliverables: ["product_discovery.md"], handled_events: [{ event_id: received.event.id, intent: "new_task", impact: "normal", note: "开始" }] });
  const proposed = (await w.works.round(w.key))!;
  expect((await f.request("work/card/update", { work_key: w.key, action: "start", revision: proposed.revision, source: "click" })).status).toBe(200);
  const main = () => ({ session: { header: { id: w.session, cwd: f.scope.projectPath }, events: w.events } });
  let judgeStarts = 0, continuations = 0;
  for (let n = 1; n <= 3; n++) {
    const run = (await w.works.round(w.key))!;
    await w.dispatch("product_discovery", `continuity-worker-${n}`);
    await writeFile(join(f.scope.projectPath, ".任务", run.task_key!, "产物快照/product_discovery.md"), `# 竞品\n版本 ${n}`);
    expect((await f.submit("promax_member_receipt", { filename: "product_discovery.md", status: "draft_ready", summary: "草稿", unverified: [], gaps: [], input_version: run.execution_version }, { callId: `continuity-receipt-${n}`, agent: w.child(`continuity-worker-${n}`) })).isError).toBe(false);
    // Only the first review is advanced by coordinator stopping. Rechecks must admit directly from repairing.
    if (n === 1) await w.stop();
    let check = (await w.works.round(w.key))!;
    expect(check.phase).toBe(n === 1 ? "checking" : "repairing");
    if (n === 1) {
      const exec = { name: "quality_judge", callId: "first-judge", agent: main() };
      await expect(enforceDispatchPlanTool("", exec, async () => { throw new Error("dispatch fixture failure"); })).rejects.toThrow("dispatch fixture failure");
      expect(await enforceDispatchPlanTool("", exec, async () => "allowed")).toBe("allowed");
      expect(await enforceDispatchPlanTool("", { ...exec, callId: "duplicate-judge" }, async () => "duplicate")).toBe("duplicate");
      const invoke = async (callId: string) => {
        const current = { ...exec, callId };
        const result = await f.hooks.get("tools/execute")!(current, async () => {
          judgeStarts++;
          return { isError: false, value: { kind: "continuable", subagentId: "continuity-judge" }, content: [] };
        });
        await f.hooks.get("tools/post-execute")!(current, result, async () => ({ kind: "accept" }));
        await f.hooks.get("tools/result")!(current, result);
      };
      await Promise.all([invoke("first-judge"), invoke("duplicate-judge")]);
      expect(judgeStarts).toBe(1);
      await f.hooks.get("subagent/end")!({ id: "continuity-judge" });
    }
    else {
      const exec = { name: "send_message", arguments: { subagent_id: "continuity-judge", message: check.review_request }, callId: `continue-${n}`, agent: main() };
      w.tick("tool/call", { name: exec.name, arguments: exec.arguments, callId: exec.callId });
      expect(await enforceDispatchPlanTool("", exec, async () => "allowed")).toBe("allowed");
      check = (await w.works.round(w.key))!;
      expect(check.phase).toBe("checking");
      expect(await enforceDispatchPlanTool("", { ...exec, callId: `duplicate-continue-${n}` }, async () => "duplicate")).toBe("duplicate");
      const invoke = async (callId: string) => {
        const current = { ...exec, callId };
        const result = await f.hooks.get("tools/execute")!(current, async () => {
          continuations++;
          await f.hooks.get("agent/inbox/inserted")!({ agent: w.child("continuity-judge"), message: { id: `m${n}`, source: { kind: "coordinator", senderSessionId: w.session } } });
          return { isError: false, value: { messageId: `m${n}` }, content: [] };
        });
        await f.hooks.get("tools/post-execute")!(current, result, async () => ({ kind: "accept" }));
        await f.hooks.get("tools/result")!(current, result);
      };
      await Promise.all([invoke(exec.callId), invoke(`duplicate-continue-${n}`)]);
      expect(continuations).toBe(n - 1);
      await f.hooks.get("subagent/end")!({ id: "continuity-judge" });
    }
    const result = await f.submit("promax_check_result", { verdict: n === 3 ? "PASS" : "REVISION_REQUIRED", acceptance: judged(check, n === 3 ? "met" : "unmet"), issues: n === 1 ? [{ id: "I1", severity: "low", artifact: "product_discovery.md", location: "竞品", evidence: "原始要求", impact: "遗漏必做项", fix: "补齐" }] : [], rechecks: n > 1 ? [{ id: "I1", state: n === 3 ? "verified" : "open", evidence: `核对版本 ${n}` }] : [], unverified: [], decisions: [], input_version: check.execution_version, review_request: check.review_request }, { callId: `continuity-check-${n}`, agent: w.child("continuity-judge") });
    expect(result.isError, String(result.value)).toBe(false);
    if (n === 3) {
      // Authoritative child completion, even after a model failure: no further main-Agent reply is required.
      await f.hooks.get("subagent/end")!({ id: "continuity-judge", runId: "terminal", stopReason: "failed" });
      expect((await w.works.round(w.key))?.phase).toBe("ended");
      expect(new ContentObjectStore(f.scope.projectPath).index().artifacts.some((a) => a.work_key === w.key)).toBe(true);
    }
    if (n < 3) {
      const planned = await f.submit("promax_repair_plan", { judge_round: n, assignments: [{ member: "product_discovery", files: ["product_discovery.md"], issue_ids: ["I1"], instruction: "补齐必做项" }] }, { callId: `continuity-plan-${n}`, agent: main() });
      expect(planned.isError, String(planned.value)).toBe(false);
    }
  }
  await w.stop();
  expect(judgeStarts).toBe(1); expect(continuations).toBe(2);
  expect((await new WorkStore(f.scope.projectPath).reviews(w.key)).issues[0]?.state).toBe("verified");
  expect((await w.works.round(w.key))?.phase).toBe("ended");
  expect((await w.works.status(w.key)).faults.some((fault) => fault.history.some((h) => h.reason.includes("没有实际派发")))).toBe(false);
});

it("R28/R29 续接生命周期：批准的恢复真实执行，在途不被误清，读取原结果不留假running且任务继续推进", async () => {
  const w = await setup();
  const received = await w.say("做竞品调研");
  await w.propose({ intent: "execute", deliverables: ["product_discovery.md"], handled_events: [{ event_id: received.event.id, intent: "new_task", impact: "normal", note: "开始竞品调研" }] });
  const proposed = (await w.works.round(w.key))!;
  expect((await f.request("work/card/update", { work_key: w.key, action: "start", revision: proposed.revision, source: "click" })).status).toBe(200);
  const task = (await w.works.round(w.key))!.task_key!;
  const main = () => ({ session: { header: { id: w.session, cwd: f.scope.projectPath }, events: w.events } });
  let modelRuns = 0;
  /** Hook-level regression; native ToolRuntime/schema/followup coverage is in native-dispatch.test.ts. */
  const run = async (name: string, childId: string, args: Record<string, unknown>, callId: string, options: { signal?: AbortSignal; hold?: Promise<void> } = {}) => {
    const exec = { name, arguments: args, callId, signal: options.signal ?? new AbortController().signal, agent: main() };
    w.tick("tool/call", { name, arguments: args, callId });
    const admission = await f.hooks.get("tools/pre-execute")!(exec, async () => ({ kind: "allow" }));
    if ((admission as { kind?: string } | undefined)?.kind === "deny") return { admission };
    const result = await f.hooks.get("tools/execute")!(exec, async () => {
      modelRuns++;
      if (options.hold) await options.hold;
      if (name === "send_message") await f.hooks.get("agent/inbox/inserted")!({ agent: w.child(childId), message: { id: `m-${callId}`, source: { kind: "coordinator", senderSessionId: w.session } } });
      return name === "send_message"
        ? { isError: false, value: { messageId: `m-${callId}` }, content: [{ type: "text", text: "message queued as the next turn" }] }
        : { isError: false, value: { kind: "continuable", subagentId: childId }, content: [{ type: "text", text: "已派发" }] };
    });
    await f.hooks.get("tools/post-execute")!(exec, result, async () => ({}));
    await f.hooks.get("tools/result")!(exec, result);
    return { admission, result };
  };
  // 1) 业务成员真实派发、落盘、回执并结束；程序进入独立检查
  const member = await run("product_discovery", "r29-pd", { prompt: "做竞品调研" }, "r29-member-1");
  expect(member.result?.isError, JSON.stringify(member)).toBe(false);
  const version = (await w.works.round(w.key))!.execution_version;
  await writeFile(join(f.scope.projectPath, ".任务", task, "产物快照/product_discovery.md"), "# 竞品\n第一版正文\n");
  expect((await f.submit("promax_member_receipt", { filename: "product_discovery.md", status: "draft_ready", summary: "草稿", unverified: [], gaps: [], input_version: version }, { callId: "r29-receipt-1", agent: w.child("r29-pd") })).isError).toBe(false);
  await f.hooks.get("subagent/end")!({ id: "r29-pd" });
  await w.stop();
  expect((await w.works.round(w.key))!.phase).toBe("checking");
  expect(w.steered.at(-1)).toContain("quality_judge");
  // 2) 第一次独立检查运行结束但没有形成有效结果；程序批准原 Judge 会话的恢复
  expect((await run("quality_judge", "r29-judge", {}, "r29-judge-1")).result?.isError).toBe(false);
  expect(modelRuns).toBe(2);
  await f.hooks.get("subagent/end")!({ id: "r29-judge" });
  await w.stop();
  expect(w.steered.at(-1)).toContain("自动恢复");
  expect((await w.works.round(w.key))!.member_seq?.quality_judge ?? 0).toBeGreaterThan(0);
  // 3) 批准的恢复必须真正续接同一 Judge 会话，不能沿用旧检查结果（R28）
  const continued = await run("send_message", "r29-judge", { subagent_id: "r29-judge", message: "按当前工作简报评审请求复查" }, "r29-judge-2");
  expect(continued.result?.isError, JSON.stringify(continued)).toBe(false);
  expect(modelRuns).toBe(3);
  await f.hooks.get("subagent/end")!({ id: "r29-judge" });
  // 4) 程序再次批准恢复；该恢复在途时，等价但过期的调用被拦，不得清掉真正在跑的成员（R29）
  await w.stop();
  expect(w.steered.at(-1)).toContain("自动恢复");
  let release!: () => void;
  const gate = new Promise<void>((resolve) => { release = resolve; });
  const inFlight = run("send_message", "r29-judge", { subagent_id: "r29-judge", message: "按当前工作简报评审请求复查" }, "r29-judge-3", { hold: gate });
  await vi.waitFor(async () => {
    expect((await w.works.observations(w.key)).some((r) => r.kind === "action_started" && r.call_id === "r29-judge-3")).toBe(true);
  });
  const expired = new AbortController();
  expired.abort();
  const blocked = await run("send_message", "r29-judge", { subagent_id: "r29-judge", message: "等价重复" }, "r29-judge-4", { signal: expired.signal });
  expect(blocked.admission).toMatchObject({ kind: "allow" });
  expect(blocked.result).toMatchObject({ isError: true, error: { code: "STALE_ACTION" } });
  const beforeWait = w.steered.length;
  await w.stop();
  expect(w.steered.length, "真正在途的成员不能被过期调用清掉").toBe(beforeWait);
  expect((await w.works.round(w.key))!.phase).toBe("checking");
  // 5) 在途恢复结束；同一恢复的重复通知读取原结果，不再执行也不留下虚假运行状态
  release();
  const settled = await inFlight;
  expect(settled.result?.isError).toBe(false);
  expect(modelRuns).toBe(4);
  await f.hooks.get("subagent/end")!({ id: "r29-judge" });
  const repeated = await run("send_message", "r29-judge", { subagent_id: "r29-judge", message: "等价重复" }, "r29-judge-5");
  expect(repeated.result?.isError, JSON.stringify(repeated)).toBe(false);
  expect(modelRuns).toBe(4);
  expect(repeated.result?.value).toEqual(settled.result?.value);
  // 6) 读取原结果之后任务仍能推进：程序再次安排原 Judge 恢复，而不是等待已结束的成员
  const beforeAdvance = w.steered.length;
  await w.stop();
  expect(w.steered.length).toBe(beforeAdvance + 1);
  expect(w.steered.at(-1)).toContain("quality_judge");
});

it("T2 a chat “采纳” adopts one suggestion only when the link is unambiguous; otherwise it is clarified and nothing is adopted", async () => {
  const w = await setup();
  await w.say("先做用户调研");
  await w.propose({ intent: "guide", card_patch: { suggestions: [{ text: "访谈三类角色各 1 人", basis: "材料分工" }, { text: "登记项拆成两个字段", basis: "只有一列" }] }, handled_events: [{ event_id: (await w.works.read(w.key)).events![0]!.id, intent: "new_task", impact: "normal", note: "先给调研建议" }] });
  const bare = await w.say("采纳");
  // Two open suggestions and a bare “采纳”: even if the coordinator picks one, the program asks which one.
  expect((await w.propose({ intent: "answer", handled_events: [{ event_id: bare.event.id, intent: "supplement", impact: "normal", suggestion: "访谈三类角色各 1 人", affects: [], note: "按访谈建议执行" }] })).isError).toBe(false);
  let card = await w.works.read(w.key);
  expect(card.suggestions?.map((s) => s.state)).toEqual(["proposed", "proposed"]);
  expect(card.events?.find((e) => e.id === bare.event.id)).toMatchObject({ state: "clarifying", note: expect.stringContaining("不明确") });
  // The reply that names the suggestion settles exactly that one, and never counts as the interviews being done.
  const named = await w.say("访谈三类角色各 1 人这条采纳");
  expect((await w.propose({ intent: "answer", handled_events: [{ event_id: named.event.id, intent: "supplement", impact: "normal", suggestion: "访谈三类角色各 1 人", affects: [], note: "访谈建议已采纳，尚未访谈" }] })).isError).toBe(false);
  card = await w.works.read(w.key);
  expect(card.suggestions?.map((s) => s.state)).toEqual(["accepted", "proposed"]);
  expect(card.events?.find((e) => e.id === named.event.id)).toMatchObject({ state: "applied", note: expect.stringContaining("不代表已执行") });
  // With a single open suggestion left, a bare reply is unambiguous.
  const reject = await w.say("不要");
  expect((await w.propose({ intent: "answer", handled_events: [{ event_id: reject.event.id, intent: "supplement", impact: "normal", suggestion: "登记项拆成两个字段", affects: [], note: "不拆字段" }] })).isError).toBe(false);
  card = await w.works.read(w.key);
  expect(card.suggestions?.map((s) => s.state)).toEqual(["accepted", "rejected"]);
});
