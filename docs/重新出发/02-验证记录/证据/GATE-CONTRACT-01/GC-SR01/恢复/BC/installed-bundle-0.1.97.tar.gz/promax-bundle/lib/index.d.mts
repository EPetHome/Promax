import { PromateProject, RotatingTokenManager, TraceUploader } from "@promax/promax-report";
import { createUserMessage } from "@deepseek-ai/dsh-llm";
import { IncomingMessage, ServerResponse } from "node:http";
//#region ../promax-ui-console/src/delivery-protocol.d.ts
/** Append-only presentation of an existing task/version result, never a second success authority. */
interface DeliveryReceipt {
  id: string;
  /** Fact ID when this is a new visible receipt for facts that matched an older historical ID. */
  projection_id?: string;
  at: string;
  task_key: string;
  reviewed_hashes: Record<string, string>;
  state: "saving" | "complete" | "saved_partial" | "failed" | "unknown";
  correction: boolean;
  text: string;
  targets: Array<{
    kind: "formal" | "draft" | "previous";
    filename: string;
    sha256: string;
    task_key?: string;
    path: string;
  }>;
}
/** Commit attempt metadata in the existing work record. Success is always read from the version store. */
interface DeliveryAttempt {
  task_key: string;
  trace_id: string;
  reviewed_hashes: Record<string, string>;
  at: string;
  /** This attempt rechecked an existing formal version; no version was committed under this task. */
  check_only?: boolean;
  error?: string;
  failure?: "failed" | "unknown";
}
//#endregion
//#region src/runtime-snapshot.d.ts
interface SnapshotComponent {
  name: string;
  version: string | null;
  /** 版本声明的证据类型：本次实际读取的字节/预置文件/宿主上报；不能只写“已安装”。 */
  evidence: string;
  /** 未知时保留原因，不回填。 */
  unknown_reason?: string;
}
interface RuntimeSnapshot {
  schema_version: 1;
  snapshot_id: string;
  captured_at: string;
  capture_point: string;
  work_key: string;
  fields: {
    record_schema: {
      schema_version: number;
    };
    team_revision: {
      team_revision_id: string | null;
      revision: number | null;
      definition_sha256: string | null;
      /** 本次实际读取的 preset 字节哈希；证明加载内容，不证明进程已使用。 */
      preset_sha256: string | null;
      source: string;
      unknown_reason?: string;
    };
    acceptance_baseline: {
      version: string;
      requirement_version: number;
    };
    frozen_input: {
      task_key: string;
      manifest_sha256: string | null;
      frozen_at: string | null;
      source: string;
      unknown_reason?: string;
    };
    loaded_components: SnapshotComponent[];
    model_tool_config: {
      runtime_version: string;
      model_route: string | null;
      config_source: string;
      config_version: string | null;
      unknown_reason?: string;
    };
  };
  unknown: Array<{
    field: string;
    reason: string;
  }>;
  immutable: true;
}
//#endregion
//#region src/handoff.d.ts
interface Handoff {
  available: string[];
  sources: Array<{
    path: string;
    sha256: string;
    range: string;
  }>;
  scope: string;
  needed_by: string[];
  gaps: string[];
}
//#endregion
//#region ../promax-ui-console/src/work-protocol.d.ts
interface WorkCondition {
  id: string;
  title: string;
  completion: string;
  kind: "decision" | "artifact" | "manual";
  filenames: string[];
  decision_key?: string;
  /** Unknown is not assumed to be non-blocking. */
  blocking?: boolean;
  evidence?: {
    at: string;
    digest: string;
    hashes: Record<string, string>;
    basis: string;
    report?: string;
    author: string;
  };
}
interface WorkFeedback {
  id: string;
  node_id?: string;
  condition_id?: string;
  artifact?: string;
  decision_id?: string;
  kind: "defect" | "requirement" | "disagreement";
  text: string;
  at: string;
  hashes: Record<string, string>;
  state: "pending" | "confirmed" | "disputed" | "resolved";
  reviews: Array<{
    state: WorkFeedback["state"];
    basis: string;
    at: string;
    author: string;
  }>;
}
declare const WORK_NODE_GATES: readonly ["employee", "checked_artifacts", "accepted_artifacts"];
type WorkNodeGate = (typeof WORK_NODE_GATES)[number];
interface WorkNode {
  id: string;
  title: string;
  completion: string;
  filenames: string[];
  gate: WorkNodeGate;
  conditions?: WorkCondition[];
  depends_on?: string[];
  /** Program-owned completion evidence, never accepted from a model. */
  evidence?: {
    at: string;
    digest: string;
    hashes: Record<string, string>;
  };
  needs_update?: boolean;
}
interface WorkScopeMove {
  node_id: string;
  condition_id?: string;
  action: "merge" | "defer";
  target_node_id?: string;
  reason: string;
}
interface WorkScopeHistory {
  id: string;
  at: string;
  author: string;
  decision: "accept" | "reject";
  reason: string;
  from_goal: string;
  to_goal: string;
  before_nodes: WorkNode[];
  after_nodes: WorkNode[];
  moves: WorkScopeMove[];
  unmet: string[];
  pending: PendingItem[];
  decisions: DecisionRecord[];
  feedback: WorkFeedback[];
  side_topics: NonNullable<WorkCard["side_topics"]>;
}
/** A closable reading page. Identity is the document version, so reopening reuses the page. */
interface DocPage {
  id: string;
  kind: "artifact" | "brief" | "check";
  filename?: string;
  /** Pinned historical version; absent means the current version. */
  sha256?: string;
  highlight?: string;
}
/** An action panel inserted into the conversation. Its binding decides whether it is still actionable. */
interface ChatItem {
  id: string;
  kind: "question" | "acceptance" | "condition" | "feedback" | "change";
  opened_at: string;
  question_id?: string;
  filename?: string;
  /** The document version the panel was opened for; a newer current version makes the panel stale. */
  sha256?: string;
  base_sha256?: string;
  node_id?: string;
  condition_id?: string;
  decision_id?: string;
  location?: string;
  /** Program record created by the submission (feedback id). */
  result_id?: string;
}
interface WorkNavigation {
  mode: "overview" | "node" | "question";
  node_id?: string;
  question_id?: string;
  filename?: string;
  highlight?: string;
  focus?: boolean;
  returned_at?: string;
  /** Presentation only; never advances a node or starts a round. */
  workspace_view?: "spine" | "artifact" | "document";
  expanded_node_ids?: string[];
  tree_scroll?: number;
  /** Legacy item tabs; kept readable, no longer opened. */
  opened_question_ids?: string[];
  /** Browsing highlight is independent from the collaboration focus and real progress. */
  located_node_id?: string;
  doc_pages?: DocPage[];
  active_doc?: string;
  chat_items?: ChatItem[];
}
/** Controlled panel content supplied by the agent; the page renders it with fixed components. */
type PanelField = {
  id: string;
  label: string;
  input: "text" | "number" | "choice";
  options?: string[];
  unit?: string;
  suggested?: string;
  required?: boolean;
};
type PanelEntry = {
  id: string;
  text: string;
  source?: string;
  suggested_group?: string;
};
type QuestionPanel = {
  type: "fields";
  fields: PanelField[];
} | {
  type: "merge";
  entries: PanelEntry[];
} | {
  type: "order";
  entries: PanelEntry[];
};
interface PendingItem {
  /** Stable business identity. Only merge when location/options are compatible. */
  decision_key?: string;
  node_id?: string;
  artifact?: string;
  location?: string;
  current_content?: string;
  effect?: string;
  timing?: "now" | "later";
  reopen_reason?: string;
  reviewed_sha256?: string;
  sources?: Array<{
    source: "ai" | "check";
    basis: string;
    reference?: string;
  }>;
  id: string;
  question: string;
  options?: string[];
  basis?: string;
  /** "check" items come from an independent check report, never from the coordinator's own opinion. */
  source?: "ai" | "check";
  panel?: QuestionPanel;
  /** 需求澄清 / 材料补充 / 方案取舍 / 成果修改; derived for legacy items. */
  kind?: "clarify" | "material" | "tradeoff" | "revision";
  /** Member id, "coordinator" or "check". */
  raised_by?: string;
  /** Program-owned times; the same question updates the original record. */
  first_at?: string;
  updated_at?: string;
  /** Whether the next step waits for this answer. Unknown is shown as unknown, never assumed. */
  blocking?: boolean;
  urgent?: boolean;
}
/** One employee input as received by the program. Its state is program-owned; the model only proposes meaning. */
interface WorkEvent {
  id: string;
  seq: number;
  at: string;
  channel: "chat" | "question" | "button" | "stop";
  text: string;
  paths?: string[];
  question_id?: string;
  suggestion?: string;
  /** Explicit option chosen with a button; no model interpretation needed. */
  choice?: string;
  priority: "high" | "normal";
  state: "received" | "clarifying" | "pending_apply" | "applied" | "answered" | "failed";
  intent?: "question" | "supplement" | "decision" | "correction" | "new_task" | "control";
  /** Running task at receipt; settlement of that task must not swallow it. */
  task_key?: string;
  input_version: number;
  note?: string;
  affects?: string[];
  handled_at?: string;
  /** Times the coordinator was asked to understand this input. */
  attempts?: number;
}
/** The coordinator's structured understanding of one received input. */
interface HandledEvent {
  event_id: string;
  intent: NonNullable<WorkEvent["intent"]>;
  impact: "high" | "normal";
  question_id?: string;
  answer?: string;
  suggestion?: string;
  affects?: string[];
  clarify?: string;
  revokes?: {
    decision_ids?: string[];
    suggestions?: string[];
  };
  note: string;
}
interface WorkTurn {
  /** Optional local review selection; never removes requirements from the full baseline. */
  review_requirement_ids?: string[];
  intent: "answer" | "guide" | "execute" | "edit";
  card_patch: {
    title?: string;
    goal?: string;
    pending?: PendingItem[];
    suggestions?: Array<{
      text: string;
      basis: string;
    }>;
    employee_said?: Array<{
      text: string;
      quote: string;
    }>;
    nodes?: WorkNode[];
    scope_change_reason?: string;
    scope_moves?: WorkScopeMove[];
    side_topic?: {
      text: string;
      reason: string;
    };
  };
  deliverables: string[];
  edit_request: null | {
    filename: string;
    base_sha256: string;
    anchor: {
      type: "heading" | "quote" | "page";
      value: string;
    };
    instruction: string;
  };
  /** Structured submissions only; legacy text blocks never classify inputs. */
  handled_events?: HandledEvent[];
}
/** What happened after the employee answered a decision; the answer alone is not the end of it. */
type DecisionState = "processing" | "awaiting_start" | "running" | "updated" | "checking" | "applied" | "partial" | "no_change" | "failed" |
/** Effective requirement; the coordinator concluded no artifact needs to change. */
"recorded" |
/** Kept as history only; a later decision or explicit withdrawal replaced it. */
"superseded" | "withdrawn";
interface DecisionRecord extends PendingItem {
  answer: string;
  answered_at: string;
  state: DecisionState;
  note?: string;
  task_key?: string;
  base_sha256?: string;
  applied_sha256?: string;
  source_event?: string;
  superseded_by?: string;
  closed_at?: string;
  /** Saved outputs the coordinator found affected; each must publish a new version before "applied". */
  affects?: string[];
}
interface ConfirmedItem {
  text: string;
  confirmed_at: string;
  /** message: verified against the employee's own words; form/decision: entered by the employee in the page. */
  source?: "message" | "form" | "decision";
  quote?: string;
}
interface WorkSuggestion {
  text: string;
  basis: string;
  /** Missing state is a legacy unaccepted suggestion, never consensus. */
  state?: "proposed" | "accepted" | "rejected" | "adjusted" | "superseded";
  history?: Array<{
    at: string;
    reply: string;
    state: "accepted" | "rejected" | "adjusted" | "superseded";
  }>;
}
interface WorkCard {
  schema_version: 1;
  /** Program delivery projections; append-only, not submission success authority. */
  delivery_receipts?: DeliveryReceipt[];
  /** Local-only effective-requirements protocol. Absent means historical, not retrospectively verified. */
  requirements_protocol?: 1;
  requirement_policy?: RequirementPolicy;
  interpretations?: Array<{
    text: string;
    quote: string;
  }>;
  acceptance_baseline?: AcceptanceBaseline;
  acceptance_history?: AcceptanceBaseline[];
  work_key: string;
  session_id: string;
  project_id: string;
  title: string;
  goal: string;
  /** The employee's first request; later messages are increments and never overwrite it. Local only. */
  origin?: {
    text: string;
    at: string;
    paths: string[];
  };
  /** Program-owned: bumps whenever the effective requirements change. */
  requirement_version?: number;
  requirement_digest?: string;
  /** Local-only input ledger (employee text is not uploaded). */
  events?: WorkEvent[];
  materials: Array<{
    /** Compatibility fields always identify original bytes, never a converted copy. */
    path: string;
    sha256: string;
    summary: string;
    source_id?: string;
    readable_path?: string;
    readable_sha256?: string;
    format?: string;
    parse_status?: "ready" | "failed";
    limitation?: string;
    error?: string;
    reads?: Array<{
      member: string;
      session_id: string;
      call_id: string;
      at: string;
      offset?: number;
      limit?: number;
    }>;
  }>;
  confirmed: ConfirmedItem[];
  pending: PendingItem[];
  /** Answered decisions and their follow-up, newest last. */
  decisions?: DecisionRecord[];
  feedback?: WorkFeedback[];
  during_run?: Array<{
    id: string;
    text: string;
    paths: string[];
    at: string;
    task_key: string;
    node_id?: string;
    question_id?: string;
  }>;
  acceptances?: Array<{
    filename: string;
    sha256: string;
    digest: string;
    at: string;
    author: string;
    condition_ids: string[];
  }>;
  suggestions?: WorkSuggestion[];
  deliverables: Array<{
    filename: string;
    member_id: string;
    current_sha256: string | null;
    /** Readable task draft, independent of published versions and acceptance. */
    draft?: {
      task_key: string;
      path: string;
      sha256: string;
      readable_at: string;
      first_readable_at: string;
      actionable_at?: string;
      actionable_client_at?: string;
    };
    status: string;
  }>;
  last_progress: string;
  updated_at: string;
  spine?: {
    nodes: WorkNode[];
  };
  scope_proposal?: {
    goal: string;
    nodes?: WorkNode[];
    reason: string;
    deliverables?: WorkCard["deliverables"];
    moves?: WorkScopeMove[];
  };
  /** Program-owned, append-only snapshots; scope exclusion is never completion. */
  scope_history?: WorkScopeHistory[];
  navigation?: WorkNavigation;
  /** Unsubmitted text; never enters confirmed or the execution brief. */
  drafts?: Record<string, string>;
  side_topics?: Array<{
    id: string;
    text: string;
    reason: string;
    node_id?: string;
    deferred: boolean;
    continued?: boolean;
  }>;
}
//#endregion
//#region ../promax-ui-console/src/effective-protocol.d.ts
/** Local-only, program-owned sources. Model wording never acquires an authority label. */
interface RequirementSource {
  id: string;
  kind: "user_request" | "user_decision";
  text: string;
  at: string;
  input_version?: number;
}
interface RequirementPolicy {
  revision: string;
  rules: Array<{
    id: string;
    text: string;
    files: string[];
    kind?: string;
    necessity?: "required" | "recommended";
    evidence_obligation?: EvidenceObligation;
    evidence_basis?: EvidenceBasisKind[];
    capability_obligation?: string[];
    applicability?: {
      when: string;
      not_applicable_reason?: string;
    };
  }>;
  capabilities: {
    browser: "disabled";
    public_web: "authorized_members_only";
    judge_web: "disabled";
    availability: "not_probed";
  };
}
interface EffectiveRequirements {
  version: number;
  sources: RequirementSource[];
  policy: RequirementPolicy;
  interpretation: string;
  assumptions: string[];
}
interface EvidenceObligation {
  /** 本项需要回答的关键问题，不是来源数量。 */
  question: string;
  /** 最低依据类型与实际用途；材料不足时记无法验证，不改变义务。 */
  min_basis: string;
}
/** R01：必需项可接受的程序依据类别；缺省表示只由 Judge 语义判定，不额外强制 SRC。 */
type EvidenceBasisKind = "requirement_record" | "source_link" | "numeric_recompute" | "program_check";
/** 由已接受回执派生的每项依据可用性（程序事实，不是成员自评）。 */
interface EvidenceAggregateRow {
  available: EvidenceBasisKind[];
  links: Array<{
    link_id: string;
    conclusion_id: string;
    source_ids: string[];
    location: string;
  }>;
  lead_only_links: string[];
  bindings?: Array<{
    filename: string;
    receipt_digest: string;
    sources: Array<{
      task_key: string;
      source_id: string;
      relative_path: string;
      sha256: string;
      qualification_sha256: string;
    }>;
  }>;
}
type EvidenceIndex = Record<string, EvidenceAggregateRow>;
interface AcceptanceItem {
  id: string;
  text: string;
  required: boolean;
  source_refs: string[];
  files: string[];
  /** 3.1 必需性：适用必需项或建议项；required 保留为兼容派生字段。 */
  necessity?: "required" | "recommended";
  /** R01/7.4：本项可接受的依据类别；缺失时 met 不被采信（结构规则可留空，不做额外 SRC 要求）。 */
  evidence_basis?: EvidenceBasisKind[];
  /** 3.1 证据义务：关键问题与最低依据类型。 */
  evidence_obligation?: EvidenceObligation;
  /** 10.1 能力/达成路径义务；冻结结果与依据，不固定工具名。 */
  capability_obligation?: string[];
  /** 3.1 适用条件；不适用项在此记理由，不进入适用分母。 */
  applicability?: {
    when: string;
    not_applicable_reason?: string;
  };
  /** 3.1 来源性质分开：用户原始要求／有效决定／真实权限／产品最低规则。 */
  source_kind?: "user_request" | "user_decision" | "product_rule";
}
interface AcceptanceBaseline {
  protocol: 1;
  version: string;
  requirement_version: number;
  requirements_digest: string;
  sources: RequirementSource[];
  policy: RequirementPolicy;
  files: string[];
  items: AcceptanceItem[];
}
interface AcceptanceResult {
  baseline_version: string;
  items: Array<{
    id: string;
    state: "met" | "unmet" | "unverifiable";
    evidence: string;
  }>;
}
interface UnverifiedItem {
  item: string;
  reason: string;
  requirement_ids?: string[];
  impact?: "blocking" | "non_blocking";
}
//#endregion
//#region src/evidence-links.d.ts
declare const KIND_VALUES: readonly ["fact", "comparison", "change", "trend", "projection", "recommendation", "unknown"];
interface EvidenceLinkInput {
  requirement_ids: string[];
  conclusion: string;
  location: string;
  /** R10：修订时显式引用已登记结论身份；首次登记省略，由程序分配。 */
  conclusion_id?: string;
  kind?: (typeof KIND_VALUES)[number];
  evidence: Array<{
    source_id: string;
    range: string;
    use?: string;
  }>;
  numeric_spec?: Record<string, string>;
  /** 拆分/合并/撤回时列出被替代的结论身份；留历史去向，不做近似匹配。 */
  supersedes?: string[];
  note?: string;
}
interface SourceReadback {
  source_id: string;
  relative_path: string;
  sha256: string;
  range: string;
  /** 支持的最小定位契约解析出的行区间；精确片段定位时缺省。 */
  lines?: [number, number];
  snippet: string;
  verified_at: string;
  task_key?: string;
  qualification_sha256?: string;
}
interface NumericCheck {
  status: "recomputed" | "unsupported";
  formula?: string;
  computed?: number;
  declared?: string;
  matched?: boolean;
  reason?: string;
  checker_version?: string;
  spec_sha256?: string;
  input?: {
    source_id: string;
    sha256: string;
    range: string;
    selected_sha256: string;
  };
  counts?: {
    rows: number;
    numerator: number;
    denominator: number;
    missing_rows: number[];
  };
  unit?: string;
  coverage?: string;
}
interface ConditionalCheck {
  /** 来源该部分内容是否可作为候选证据；线索/诊断来源不满足 source_link 依据。 */
  usable_as_evidence: boolean;
  reason: string;
}
interface AcceptedEvidenceLink extends EvidenceLinkInput {
  /** Conservative textual dependencies, not a semantic approval. Old missing fingerprints cannot auto-carry. */
  dependency_sha256?: string;
  continued_from?: {
    link_id: string;
    artifact_sha256: string;
  };
  link_id: string;
  conclusion_id: string;
  /** null = 首次登记，stage 不占号；显式修订保留原始请求身份参与幂等。 */
  requested_conclusion_id?: string | null;
  artifact_sha256: string;
  /** 来源在输入清单中的使用资格；线索/诊断来源不冒充候选证据，交由 Judge 判支持关系。 */
  source_qualification: Array<{
    source_id: string;
    use_qualification: string | null;
    content_kind: string | null;
  }>;
  source_readback: SourceReadback[];
  conditional: ConditionalCheck;
  numeric_check?: NumericCheck;
  matched_at: string;
}
//#endregion
//#region ../promax-ui-console/src/work-control.d.ts
/** Program-owned control state of one step; the business phase is tracked separately. */
type ControlState = "idle" | "running" | "aligning" | "waiting_user" | "recovering" | "needs_fix" | "done" | "stopping" | "stopped";
type FaultClass = "proposal_invalid" | "member_run_failed" | "member_output_missing" | "member_receipt_missing" | "check_run_failed" | "check_output_invalid" | "commit_failed" | "missing_material" | "missing_permission" | "missing_tool" | "member_declined" | "request_exhausted";
interface FaultRecord {
  /** `${step}:${class}`; identity never includes message text, session, round or process. */
  key: string;
  step: string;
  class: FaultClass;
  state: "recovering" | "waiting" | "needs_fix" | "resolved";
  /** Failures observed for this fault; recoveries used = min(attempts, limit). */
  attempts: number;
  limit: number;
  first_at: string;
  last_at: string;
  history: Array<{
    at: string;
    evidence: string;
    reason: string;
    strategy: string;
  }>;
  task_key?: string;
  resume?: string;
  runtime_version?: string;
  /** Defect delivery as confirmed by the backend; "local" when there is no upload identity. */
  report?: {
    state: "local" | "pending" | "confirmed" | "failed";
    key?: string;
    at: string;
  };
  resolved_at?: string;
}
interface WorkAlignment {
  id: string;
  event_id: string;
  affects: string[];
  state: "active" | "resolved";
  at: string;
  note: string;
  resolved_at?: string;
}
interface UsageRecord {
  at: string;
  step: string;
  kind: "turn" | "recovery";
  input_tokens: number;
  output_tokens: number;
  event_seq: number;
}
/** Durable facts in `.工作/{key}/状态.yml`; everything shown as Agent Status is derived from these plus card/round. */
interface StoredStatus {
  schema_version: 1;
  faults: FaultRecord[];
  alignments: WorkAlignment[];
  checkpoint?: {
    at: string;
    phase: string;
    task_key?: string;
    judge_round?: number;
    hashes: Record<string, string>;
    note: string;
  };
  usage: UsageRecord[];
  /** Explicit record of status writes that failed; never silently dropped. */
  write_errors: Array<{
    at: string;
    message: string;
  }>;
  stop?: {
    task_key: string;
    requested_at: string;
    confirmed_at?: string;
    outcome?: "cancelled" | "not_running";
  };
}
interface StepStatus {
  id: string;
  label: string;
  files: string[];
  business: "generate" | "check" | "repair" | "idle";
  control: ControlState;
  detail?: string;
  recoveries?: {
    used: number;
    limit: number;
  };
}
interface AgentStatus {
  control: ControlState;
  label: string;
  steps: StepStatus[];
  requirement_version: number;
  execution_version?: number;
  task_key?: string;
  phase?: string;
  unprocessed: Array<{
    id: string;
    text: string;
    priority: WorkEvent["priority"];
    at: string;
  }>;
  blocks: Array<{
    kind: "question" | "alignment" | "fault" | "stop";
    step?: string;
    detail: string;
    since: string;
  }>;
  faults: FaultRecord[];
  recent_error?: string;
  checkpoint?: StoredStatus["checkpoint"];
  resume?: string;
  usage: {
    turns: number;
    input_tokens: number;
    output_tokens: number;
    recovery_turns: number;
  };
  write_errors: StoredStatus["write_errors"];
}
//#endregion
//#region ../promax-ui-console/src/review-protocol.d.ts
/** Local work-owned review history. Never inferred from conversational prose. */
interface ReviewIssue {
  id: string;
  severity: "high" | "medium" | "low";
  artifact: string;
  location: string;
  evidence: string;
  impact: string;
  fix: string;
  owner_member_id?: string;
  kind?: "defect" | "suggestion" | "evidence_gap" | "business_choice";
}
interface IssueRecheck {
  id: string;
  state: "open" | "verified" | "unverifiable";
  evidence: string;
}
interface RepairPlan {
  judge_round: number;
  assignments: Array<{
    member: string;
    files: string[];
    issue_ids: string[];
    instruction: string;
  }>;
}
//#endregion
//#region src/work-store.d.ts
interface WorkRound {
  delivery?: DeliveryAttempt;
  effective_requirements?: EffectiveRequirements;
  acceptance_baseline?: AcceptanceBaseline;
  acceptance_scope?: string[];
  /** 13.1 不可变运行快照；在任务启动时捕获，跨版本工作各自保留，不被后续升级覆盖。 */
  runtime_snapshot?: RuntimeSnapshot;
  /** R07：本次工作历次快照身份（不可变留存于 .工作/<key>/运行快照/），讨论回合沿用不丢。 */
  snapshot_ids?: string[];
  /** R10：被替换掉的历次已接受回执（含已核验关联），用于保留结论身份与内容历史。 */
  receipt_history?: MemberReceipt[];
  /** 已结束任务的权威回执留在同一工作记录中；不进入模型上下文、不靠派生索引留历史。 */
  receipt_archives?: Record<string, MemberReceipt[]>;
  evidence_task_key?: string;
  check_only?: boolean;
  children?: Record<string, string>;
  review_group?: string;
  review_request?: string;
  repair_plan?: RepairPlan;
  previous_check?: string;
  repair_round?: number;
  judge_round?: number;
  phase?: "generating" | "checking" | "repairing" | "ended";
  allowed_members?: string[];
  check_scope?: string;
  reviewed_hashes?: Record<string, string>;
  /** The latest finished check and what it was bound to; survives later discussion rounds as history. */
  last_check?: {
    report: string;
    judge_round: number;
    reviewed_hashes: Record<string, string>;
    requirements_digest?: string;
    verdict?: "PASS" | "REVISION_REQUIRED" | "INCOMPLETE";
    acceptance_baseline?: AcceptanceBaseline;
    acceptance?: AcceptanceResult;
    /** R01：接受时由权威回执计算的依据索引；完成判定、指标与界面投影共用。 */
    acceptance_evidence?: EvidenceIndex;
    current_acceptance_evidence?: EvidenceIndex;
    unverified?: UnverifiedItem[];
    blocking_issue_ids?: string[];
    delivery_saved?: boolean;
  };
  decision_ids?: string[];
  node_id?: string;
  /** The coordinator was asked once to re-emit a missing work block for this employee message. */
  format_retry?: boolean;
  /** Frozen at authorization; in-flight discussion must not rewrite the task's requirement version. */
  execution_digest?: string;
  /** Accepted suggestions at authorization, not later chat changes. */
  followed_suggestions?: string[];
  /** Requirements the check was run against; a later change makes the check historical. */
  requirements_digest?: string;
  revision: string;
  event_seq: number;
  turn: WorkTurn;
  source: "proposal" | "click" | "countdown";
  task_key?: string;
  attachments: string[];
  demand: string;
  unverified: Array<{
    item: string;
    reason: string;
  }>;
  edit?: WorkTurn["edit_request"];
  /** 2 = structured receipts/check results are the only advancing authority. Absent on historical rounds. */
  protocol?: 2;
  /** Card requirement version frozen at authorization. */
  execution_version?: number;
  /** Accepted, persisted member receipts keyed by deliverable filename. */
  receipts?: Record<string, MemberReceipt>;
  /** Accepted, persisted check results keyed by judge round. */
  check_results?: Record<string, CheckResultRecord>;
  /** The coordinator's committed structured proposal for the current discussion turn. */
  structured?: {
    call_id: string;
    seq: number;
    at: string;
  };
  /** A program-arranged local revision of existing outputs after an employee decision. */
  revise?: {
    decision_ids: string[];
    event_ids: string[];
    instruction: string;
  };
  /** Automation paused on an unrecoverable fault; drafts kept, nothing marked passed. */
  halted?: "needs_fix";
  /** Drafts produced under requirements that changed during the run; never committed as current. */
  stale_files?: string[];
  /** Per member: only calls/failures after this session seq belong to the current attempt (set by a recovery). */
  member_seq?: Record<string, number>;
  /** Per member: session seq at which the coordinator was told to dispatch it. */
  notified?: Record<string, number>;
}
interface MemberReceipt {
  handoff?: Handoff;
  member: string;
  filename: string;
  sha256: string;
  status: "draft_ready" | "blocked";
  phase: "generating" | "repairing";
  repair_round: number;
  summary: string;
  unverified: Array<{
    item: string;
    reason: string;
  }>;
  gaps: string[];
  blocked_reason?: "missing_material" | "missing_permission" | "missing_tool" | "conflict";
  input_version: number;
  call_id: string;
  at: string;
  /** R03/R04：程序已回读核验的结论关联；这是支撑依据索引的权威载荷。 */
  evidence_links?: AcceptedEvidenceLink[];
  /** R02：关联载荷摘要，参与幂等判断，避免正文不变时跳过关联修订。 */
  evidence_digest?: string;
  evidence_update?: {
    mode: "patch" | "replace";
    withdraw: string[];
  };
  evidence_request_digest?: string;
  evidence_base_digest?: string;
  evidence_continuity?: Array<{
    conclusion_id: string;
    state: "continued" | "invalidated" | "withdrawn";
    reason: string;
  }>;
  baseline_version?: string;
}
interface CheckResultRecord {
  /** Frozen program evaluation scope; absent on historical records, never backfilled as a new run. */
  evaluation_binding?: {
    scope: string[];
    snapshot_id: string | null;
    evaluator_version: string;
  };
  /** Program snapshot of mandatory rechecks at submission; absent in older records. */
  required_recheck_ids?: string[];
  acceptance?: AcceptanceResult;
  /** R01：接受时按权威回执计算的依据索引；完成计算、Q1与界面投影共用同一份事实。 */
  acceptance_evidence?: EvidenceIndex;
  current_acceptance_evidence?: EvidenceIndex;
  judge_round: number;
  verdict: "PASS" | "REVISION_REQUIRED" | "INCOMPLETE";
  scope: string;
  reviewed_hashes: Record<string, string>;
  issues: ReviewIssue[];
  rechecks?: IssueRecheck[];
  review_request?: string;
  unverified: UnverifiedItem[];
  decisions: Array<{
    id: string;
    question: string;
    options: string[];
    location: string;
    evidence: string;
    artifact?: string;
    decision_key?: string;
    effect?: string;
    current_content?: string;
    timing?: "now" | "later";
    reopen_reason?: string;
  }>;
  report: string;
  input_version: number;
  call_id: string;
  at: string;
}
//#endregion
//#region src/recycle-bin.d.ts
interface Header {
  id: string;
  cwd?: string;
  parentSession?: string;
  origin?: string;
}
interface Workspace {
  id: string;
  path: string;
  title: string;
  sessionIds: readonly string[];
}
interface LiveAgent {
  id: string;
  status: string;
  session: {
    header: Header;
  };
  inbox: {
    hasPending: boolean;
  };
  runMaintenance<T>(task: () => Promise<T>): Promise<T>;
}
interface AgentHandle {
  agent: LiveAgent;
  dispose(): Promise<void>;
}
type Rpc = (request: {
  rpcId?: string;
  payload?: Record<string, unknown>;
}, ...rest: unknown[]) => unknown;
interface RecycleHost {
  workspaceRegistry: {
    get?(id: string): Workspace | undefined;
    delete?(id: string): Promise<boolean>;
  };
  sessionPersistence: {
    list(): Promise<Header[]>;
    locate(header: Header): {
      path: string;
      kind: string;
    } | undefined;
  };
  agents: {
    list(): LiveAgent[];
    create(options: Record<string, unknown>): Promise<AgentHandle>;
    resume(options: Record<string, unknown>): Promise<AgentHandle>;
  };
  sessions: {
    flush(session: LiveAgent['session']): Promise<unknown>;
  };
  apiProxy: Record<string, Record<string, Rpc>>;
}
interface DeleteTarget {
  kind: 'project' | 'session';
  workspaceId: string;
  sessionId?: string;
}
interface DeletePreview extends DeleteTarget {
  title: string;
  projectTitle: string;
  sessionCount: number;
  fileCount: number;
  bytes: number;
  revision: string;
}
/** Local single-host recycle bin; registry identities stay stable until permanent removal. */
declare function createRecycleBin(host: RecycleHost, projectRoot: string, dshHome: string): Promise<{
  list: () => {
    items: {
      id: string;
      deletedAt: string;
      title: string;
      projectTitle: string;
      sessionCount: number;
      fileCount: number;
      bytes: number;
      revision: string;
      kind: "project" | "session";
      workspaceId: string;
      sessionId?: string;
    }[];
  };
  assertAllowed: (input: Record<string, unknown>) => void;
  beginRequest: (input: Record<string, unknown>) => () => void;
  wasDeleted: (path: string) => boolean;
  dispose: () => void;
  preview: (target: DeleteTarget) => Promise<DeletePreview>;
  remove: (target: DeleteTarget, revision: string) => Promise<{
    items: {
      id: string;
      deletedAt: string;
      title: string;
      projectTitle: string;
      sessionCount: number;
      fileCount: number;
      bytes: number;
      revision: string;
      kind: "project" | "session";
      workspaceId: string;
      sessionId?: string;
    }[];
    id: string;
  }>;
  restore: (id: string) => Promise<{
    items: {
      id: string;
      deletedAt: string;
      title: string;
      projectTitle: string;
      sessionCount: number;
      fileCount: number;
      bytes: number;
      revision: string;
      kind: "project" | "session";
      workspaceId: string;
      sessionId?: string;
    }[];
    workspaceId: string;
  }>;
  purge: (id: string) => Promise<{
    items: {
      id: string;
      deletedAt: string;
      title: string;
      projectTitle: string;
      sessionCount: number;
      fileCount: number;
      bytes: number;
      revision: string;
      kind: "project" | "session";
      workspaceId: string;
      sessionId?: string;
    }[];
  }>;
}>;
//#endregion
//#region ../promax-ui-console/src/client/task-state.d.ts
declare const INFORMATION_KEYS: readonly ["goal", "target_user", "scenario", "pain_point", "scope", "constraint", "success_criteria", "competitive_difference", "requirements_priority"];
type InformationKey = typeof INFORMATION_KEYS[number];
//#endregion
//#region ../promax-ui-console/src/client/team-state.d.ts
interface TeamMember {
  memberId: string;
  displayName: string;
  objective: string;
  role: 'coordinator' | 'worker';
  enabled: boolean;
  moduleRef?: string;
  instructions?: string;
  provides: InformationKey[];
  requires: InformationKey[];
}
interface TeamArtifactDefinition {
  relativePath: string;
  producedBy: string;
  required?: boolean;
}
//#endregion
//#region ../promax-ui-console/src/client/dispatch-planning.d.ts
declare const DISPATCH_PLAN_PROTOCOL = "promax.dispatch-plan/v1";
interface DispatchPlanMember {
  memberId: string;
  selected: boolean;
  reason: string;
  deliverables: string[];
}
interface DispatchPlan {
  protocol: typeof DISPATCH_PLAN_PROTOCOL;
  planId: string;
  assessment: string;
  members: DispatchPlanMember[];
}
interface DispatchPlanTeam {
  members: Pick<TeamMember, 'memberId' | 'displayName' | 'objective'>[];
  artifacts: TeamArtifactDefinition[];
}
//#endregion
//#region src/index.d.ts
/** The installed bundle version; recorded with faults and defects as the version they occurred in. */
declare const BUNDLE_VERSION: string;
interface WorkspaceRecord {
  id: string;
  path: string;
  title: string;
  sessionIds: readonly string[];
}
interface WorkspaceRegistry {
  create(path: string, title?: string): Promise<WorkspaceRecord>;
  get?(workspaceId: string): WorkspaceRecord | undefined;
  delete?(workspaceId: string): Promise<boolean>;
}
interface WebServer {
  register(route: {
    kind: "prefix";
    path: string;
    handler: (request: IncomingMessage, response: ServerResponse) => void | Promise<void>;
  }): () => void;
}
interface SettingsScope<T> {
  get(): T;
  watch(listener: (next: T, previous: T) => void | Promise<void>): () => void;
  update(patch: Partial<T>): Promise<T>;
}
interface SettingsService {
  register<T>(ns: string, schema: unknown, options: {
    base: T;
    applies: "live" | "restart";
  }): SettingsScope<T>;
}
interface CredentialsService {
  resolve(ref: string): Promise<{
    value: string;
    source: string;
  } | undefined>;
}
interface MappedToolRunContext {
  callId: string;
  rootCallId: string;
  token: symbol;
  agent?: unknown;
  signal: AbortSignal;
  deferContext(context: unknown): void;
  concludeTurn(): void;
}
interface MappedToolResult {
  isError: boolean;
  value?: unknown;
  content: readonly unknown[];
  error?: {
    message?: string;
  };
  additionalContexts?: readonly unknown[];
  concludesTurn?: true;
}
interface MappedToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  output: {
    schema: Record<string, unknown>;
    render(args: unknown, value: unknown): Array<{
      type: "text";
      text: string;
    }>;
  };
  execute(args: unknown, exec: MappedToolRunContext): Promise<unknown>;
}
interface ToolsService {
  schemas(): Array<{
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  }>;
  register(definition: MappedToolDefinition): () => void;
  get(name: string, scope?: unknown): MappedToolDefinition | undefined;
  execute(exec: {
    callId: string;
    rootCallId: string;
    parent: symbol;
    name: string;
    arguments: unknown;
    agent?: unknown;
    signal: AbortSignal;
  }): Promise<MappedToolResult>;
}
interface PluginFiber {
  dispose(): void | Promise<void>;
}
interface ChildAgentContext {
  agent: unknown;
  tools: ToolsService;
  systemPrompt: {
    assemble(input: {
      scope: unknown;
    }): Promise<{
      sections: Array<{
        name: string;
        text?: string;
      }>;
    }>;
  };
  effect(setup: () => void | (() => void), label?: string): void;
}
interface CreatedAgentPayload {
  agent: {
    session: {
      header: {
        origin?: string;
      };
    };
    ctx: ChildAgentContext;
  };
}
interface LocalTelemetry {
  admit(sessionId: string, workspace: string): Promise<void>;
  observation(sessionId: string, attributes: Record<string, unknown>): string;
  traceId(sessionId: string): string;
}
interface HostContext extends Omit<RecycleHost, "workspaceRegistry"> {
  promaxAuth: RotatingTokenManager;
  llm: unknown;
  workspaceRegistry: WorkspaceRegistry;
  webServer: WebServer;
  settings: SettingsService;
  credentials: CredentialsService;
  tools: ToolsService;
  effect(setup: () => void | (() => void), label?: string): void;
  provide(name: string, service: unknown): void;
  on(event: "webserver/index-inject", listener: (table: Array<Record<string, unknown>>) => void): void;
  on(event: "credentials/reference-updated", listener: (ref: string) => void): void;
  on(event: "tools/change", listener: () => void): void;
  on(event: "tools/pre-execute", listener: (exec: DispatchToolExecution, next: () => Promise<unknown>) => Promise<unknown>): void;
  on(event: "agent/turn-stopping", listener: (payload: DispatchTurnStopping) => void | Promise<void>): void;
  on(event: "agent/created", listener: (payload: CreatedAgentPayload) => void): void;
  plugin(plugin: unknown, config: Record<string, unknown>): Promise<PluginFiber>;
  get?(name: "promaxTelemetry"): LocalTelemetry | undefined;
  get?(name: "promaxUploader"): TraceUploader | undefined;
  emit(event: "promax/decision", payload: Record<string, unknown>): void;
}
/** Captured once by the executing module; never re-read installation bytes at HTTP request time. */
declare const BUNDLE_LOAD_IDENTITY: Readonly<{
  module_sha256: string;
  unknown_reason?: never;
  component: "promax-bundle";
  version: string;
  evaluated_at: string;
} | {
  module_sha256: null;
  unknown_reason: string;
  component: "promax-bundle";
  version: string;
  evaluated_at: string;
}>;
declare const name = "promax-workspace-bootstrap";
declare const inject: string[];
interface Config {
  /** STD-v0.1 Promax-only runtime health and context policy; unrelated sessions are untouched. */
  chainContext?: {
    enabled: boolean;
    toolConfigVersion?: string;
    capacity?: {
      provider: string;
      model: string;
      contextWindow: number;
      outputReserve: number;
      evidence: string;
    };
  };
  apiBaseUrl: string;
  feishuMcpUrl?: string;
}
type TaskRunCancellationState = "running" | "stop_requested" | "draining" | "cancelled" | "completed" | "failed";
type TaskRunJudgeState = "absent" | "pass" | "fail" | "appealed" | "human_required" | "force_released" | "unverified";
type TaskJudgeRepairState = "repairing" | "judging" | "passed" | "exhausted";
interface TaskJudgeRepairSnapshot {
  state: TaskJudgeRepairState;
  round: number;
  maxRounds: number;
  reasons: string[];
  updatedAt: string;
}
interface TaskDeliverableFile {
  name: string;
  relativePath: string;
  path: string;
  bytes: number;
  modifiedAt: string;
}
type TaskHistoryStatus = "running" | "completed" | "failed";
interface TaskRunFileSnapshot {
  taskKey: string;
  parentSessionId: string;
  createdAt: string;
  cancellation: TaskRunCancellationState;
  runEpoch: number;
  manifestPath: string;
  inputManifestPath: string;
  confirmedMemberIds: string[];
  artifactStates: Array<{
    path: string;
    memberId: string;
    exists: boolean;
    nonEmpty: boolean;
  }>;
  deliverablePath: string;
  deliverableFiles: TaskDeliverableFile[];
  judge: {
    path: string;
    memberId: "quality_judge";
    state: TaskRunJudgeState;
    exists: boolean;
    nonEmpty: boolean;
    reason?: string;
  };
  repair?: TaskJudgeRepairSnapshot;
  observedAt: string;
}
interface TaskHistoryItem {
  sessionId: string;
  taskKey: string;
  createdAt: string;
  status: TaskHistoryStatus;
  fileCount: number;
  deliverablePath: string;
  deliverableFiles: TaskDeliverableFile[];
  judge: TaskRunFileSnapshot["judge"];
  observedAt: string;
  error?: string;
}
interface DispatchToolExecution {
  callId?: string;
  name: string;
  arguments?: unknown;
  agent?: {
    session: {
      header: {
        id: string;
        origin?: string;
        cwd?: string;
        parentSession?: string;
      };
      events?: readonly DispatchSessionEvent[];
    };
  };
}
declare function frozenInputMutationReason(exec: DispatchToolExecution): string | undefined;
interface DispatchSessionEvent {
  type: string;
  data: unknown;
  seq?: number;
  time?: number;
}
interface DispatchAgent {
  session: {
    header: {
      id: string;
      origin?: string;
      cwd?: string;
      parentSession?: string;
    };
    events: readonly DispatchSessionEvent[];
  };
  steer(message: ReturnType<typeof createUserMessage>): void;
}
interface DispatchTurnStopping {
  agent: DispatchAgent;
  turn: number;
  signal: AbortSignal;
}
declare const PROMAX_FEISHU_MCP_SETTINGS_NS = "promax-feishu-mcp";
declare const PROMAX_CONNECTIONS_SETTINGS_NS = "promax-connections";
declare const FEISHU_MCP_SERVER_NAME = "feishu";
declare const FEISHU_MCP_PACKAGE = "@larksuiteoapi/lark-mcp";
declare const FEISHU_MCP_TRANSPORT = "stdio";
declare const FEISHU_MCP_CREDENTIAL_REFS: readonly ["APP_ID", "APP_SECRET"];
type FeishuMcpConnectionState = "disabled" | "credentials-required" | "connecting" | "connected" | "error";
interface FeishuMcpSettings {
  enabled: boolean;
  probe: number;
  connection: {
    probe: number;
    state: FeishuMcpConnectionState;
    tools: string[];
    checkedAt: string;
    message: string;
  };
}
type CustomMcpTransport = "stdio" | "streamable-http";
type CustomMcpConnectionState = FeishuMcpConnectionState;
interface CustomMcpCredentialBinding {
  name: string;
  ref: string;
}
interface CustomMcpConnectionSettings {
  serverName: string;
  displayName: string;
  transport: CustomMcpTransport;
  command: string;
  args: string[];
  url: string;
  env: CustomMcpCredentialBinding[];
  headers: CustomMcpCredentialBinding[];
  enabled: boolean;
  probe: number;
  connection: FeishuMcpSettings["connection"];
}
interface CustomMcpSettings {
  entries: CustomMcpConnectionSettings[];
}
type FeishuOpenClawToolName = "feishu_bitable_app" | "feishu_bitable_app_table" | "feishu_bitable_app_table_field" | "feishu_bitable_app_table_record" | "feishu_docx_import" | "feishu_docx_raw_content" | "feishu_spreadsheet_sheet" | "feishu_spreadsheet_sheet_range_read";
interface FeishuToolMapping {
  openClawTool: FeishuOpenClawToolName;
  skillIds: readonly string[];
  defaultAction?: string;
  actions: Readonly<Record<string, string>>;
  parameters: Record<string, unknown>;
  unsupportedReason?: string;
  transport?: "open-api";
}
/**
 * OpenClaw aliases route to the observed lark-mcp tools or the two read-only Sheets APIs. Targets are the exact public names
 * registered by dsh-mcp-client for @larksuiteoapi/lark-mcp 0.5.1. An empty
 * action table is intentional evidence that the current MCP has no equivalent;
 * those aliases remain callable only so they can fail with an actionable error.
 */
declare const FEISHU_TOOL_MAPPINGS: readonly FeishuToolMapping[];
/**
 * Owns the built-in Feishu connection without creating a Promax-specific
 * HTTP/RPC contract. The settings page writes only the generic settings and
 * credentials seams; secret values are resolved only for the child process
 * operation and are never copied into settings, tool status, or diagnostics.
 */
declare function installFeishuMcpRuntime(ctx: HostContext): void;
/**
 * Owns user-created MCP entries from the generic connection namespace. Secret
 * values are resolved only while constructing one live plugin instance; the
 * settings document stores credential references and key names, never values.
 */
declare function installCustomMcpRuntime(ctx: HostContext): void;
/** Derives a bounded filesystem key from the demand, or from attachment content for file-only input. */
declare function taskKeyFromSubmission(demand: string, attachments: readonly {
  name: string;
  text: string;
}[]): string;
/** Stores user-picked files under the current product workspace and returns prompt-safe relative paths. */
declare function saveTaskAttachments(workspacePath: string, sessionIdValue: string, values: unknown): Promise<string[]>;
/** Claims a new task workspace without guessing identities for historical deliverables. */
declare function ensureSessionOutputDirectory(workspacePath: string, sessionIdValue: string, requestedNameValue: string): Promise<{
  sessionName: string;
  taskKey: string;
  relativePath: string;
}>;
declare function ensureProjectWorkspace(workspaceRegistry: WorkspaceRegistry, root: string, projectName: string, owner: {
  employee_id: string;
  name: string;
  role: "owner";
}, mapping?: {
  project_id: string;
  name: string;
}): Promise<WorkspaceRecord>;
declare function registerProjectWorkspaces(registry: WorkspaceRegistry, root: string, _owner: {
  employee_id: string;
  name: string;
  role: "owner";
}): Promise<WorkspaceRecord[]>;
declare function openCompanyProject(registry: WorkspaceRegistry, root: string, project: PromateProject, employeeId: string, recycle?: Pick<Awaited<ReturnType<typeof createRecycleBin>>, "beginRequest">): Promise<WorkspaceRecord>;
declare function dispatchTeamFromRevision(value: unknown): DispatchPlanTeam;
/** Opens a server-owned planning gate before the model sees the demand. */
declare function beginDispatchPlan(root: string, input: {
  sessionId: string;
  taskKey: string;
  rosterMemberIds: string[];
  teamRevision: unknown;
}): Promise<{
  planId: string;
  taskKey: string;
}>;
/** Only the native turn hook supplies these committed events; no HTTP route accepts a generated plan. */
declare function saveGeneratedDispatchPlan(root: string, session: DispatchAgent["session"]): Promise<void>;
declare function readGeneratedDispatchPlan(root: string, input: {
  sessionId: string;
  planId: string;
}): Promise<DispatchPlan | undefined>;
/** Freezes the user-picked member ids once; a different retry cannot replace them. */
declare function confirmDispatchPlan(root: string, input: {
  sessionId: string;
  planId: string;
  confirmedMemberIds: string[];
  plan?: unknown;
}): Promise<{
  planId: string;
  taskKey: string;
  confirmedMemberIds: string[];
  confirmedAt: string;
}>;
interface PlanningAttachmentContext {
  path: string;
  name: string;
  mediaType: string;
  bytes: number;
  readablePath: string;
  textCharacters: number;
  excerpt: string;
  truncated: boolean;
  converter?: string;
  pageCount?: number;
}
/** Converts uploaded documents before planning and returns a bounded, model-readable context. */
declare function prepareTaskAttachmentsForPlanning(workspacePath: string, sessionIdValue: string, paths: readonly string[]): Promise<PlanningAttachmentContext[]>;
type DispatchEvidencePreparationResult = {
  manifestPath: string;
  sources: number;
  replacedInvalidManifest: boolean;
};
/** Materializes the server-owned immutable input before any confirmed member can start. */
declare function prepareDispatchEvidenceInput(input: {
  workspacePath: string;
  sessionId: string;
  taskKey: string;
  demand: string;
  attachmentPaths: string[];
  frozenAt: string;
  telemetry?: LocalTelemetry;
}): Promise<DispatchEvidencePreparationResult>;
/** Derives the final task key, claims its output directory, and freezes the exact input package. */
declare function prepareTaskSubmission(input: {
  workspacePath: string;
  sessionId: string;
  demand: string;
  attachmentPaths: string[];
  frozenAt: string;
  telemetry?: LocalTelemetry;
}): Promise<DispatchEvidencePreparationResult & {
  taskKey: string;
  sessionName: string;
  attachments: PlanningAttachmentContext[];
}>;
/** Converts once, freezes the verified package, and returns the same readable content used for planning. */
declare function prepareTaskSubmissionInput(input: {
  workspacePath: string;
  sessionId: string;
  taskKey: string;
  demand: string;
  attachmentPaths: string[];
  frozenAt: string;
  telemetry?: LocalTelemetry;
}): Promise<DispatchEvidencePreparationResult & {
  attachments: PlanningAttachmentContext[];
}>;
/** Accepts canonical tool values only, never assistant text claiming a child identity. */
declare function recordWorkChild(exec: DispatchToolExecution, result: {
  isError: boolean;
  value?: unknown;
}): Promise<void>;
/**
 * Role- and phase-specific tool authorization for a bound member. Retrieval, skills and structured submission are
 * explicitly allowed by duty; sibling dispatch, direct employee questions and cross-role submissions stay denied.
 * Write paths are still checked separately against the authorized snapshot closure.
 */
declare function memberToolDenial(member: string, round: Pick<WorkRound, "phase" | "protocol">, name: string): string | undefined;
/** Blocks every planning-stage tool and enforces the immutable confirmed member allowlist during execution. */
declare function enforceDispatchPlanTool(root: string, exec: DispatchToolExecution, next: () => Promise<unknown>, policyVersion?: string): Promise<unknown>;
/** Prevents settlement until the manifest's business files and independent Judge report exist on disk. */
declare function enforceConfirmedDispatchCompleteness(root: string, payload: DispatchTurnStopping, telemetry?: LocalTelemetry, uploader?: TraceUploader): Promise<void>;
/** Members get their own bounded brief; they never receive the coordinator's protocol. */
declare function memberWorkContext(card: WorkCard, round: WorkRound | undefined, member: string | undefined): string;
/** Members whose latest run in this phase ended without finishing (dsh sync error or background settlement). */
declare function failedWorkMembers(events: readonly DispatchSessionEvent[], round: Pick<WorkRound, "children" | "allowed_members">): Set<string>;
/** Stable across clients for the same fault class and step kind; content never enters the fingerprint. */
declare function defectFingerprint(fault: Pick<FaultRecord, "class" | "step">): string;
/** Minimal defect record: identity, location, version, counts and evidence references. No chat, material text or keys. */
declare function defectRequest(card: WorkCard, fault: FaultRecord, key: string): {
  project_id: string;
  defect_id: string;
  fingerprint: string;
  work_id: string;
  task_key: string | null;
  step: string;
  category: FaultClass;
  summary: string;
  runtime_version: string;
  first_seen: string;
  last_seen: string;
  occurrences: number;
  resume_position: string;
  evidence_refs: string[];
};
interface TaskRunArtifactRegistration {
  path: string;
  memberId: string;
}
/** Seals the confirmed output contract beside the immutable input manifest before execution starts. */
declare function sealTaskRunManifest(workspacePath: string, input: {
  sessionId: string;
  taskKey: string;
  confirmedAt: string;
  confirmedMemberIds: string[];
  artifacts: TaskRunArtifactRegistration[];
  teamRevision: unknown;
}): Promise<{
  manifestPath: string;
  artifactPaths: string[];
  judgePath: string;
  runEpoch: number;
}>;
/** Reads the exact artifact list from the sealed task manifest, then observes only those disk paths. */
declare function readTaskRunFiles(workspacePath: string, input: {
  sessionId: string;
  taskKey: string;
}): Promise<TaskRunFileSnapshot>;
/** Lists task assets from session-scope files and current disk contents; no browser state participates. */
declare function readTaskHistory(workspacePath: string): Promise<TaskHistoryItem[]>;
/** Resolves only the current task's real delivery directory for the native file-manager action. */
declare function resolveTaskDeliverableDirectory(workspacePath: string, input: {
  sessionId: string;
  taskKey: string;
}): Promise<string>;
/** Persists one idempotent cancellation transition before/after runtime work. */
declare function controlTaskRunFiles(workspacePath: string, input: {
  sessionId: string;
  taskKey: string;
  state: TaskRunCancellationState;
  runEpoch: number;
  updatedAt: string;
}): Promise<{
  state: TaskRunCancellationState;
  runEpoch: number;
  updatedAt: string;
  changed: boolean;
}>;
declare function coordinatorContext(card: WorkCard, round: WorkRound | undefined, status: AgentStatus, current: ReadonlyArray<{
  filename: string;
  current_sha256: string;
}>): string;
declare function apply(ctx: HostContext, config: Config): Promise<void>;
//#endregion
export { BUNDLE_LOAD_IDENTITY, BUNDLE_VERSION, Config, CustomMcpConnectionSettings, CustomMcpConnectionState, CustomMcpCredentialBinding, CustomMcpSettings, CustomMcpTransport, FEISHU_MCP_CREDENTIAL_REFS, FEISHU_MCP_PACKAGE, FEISHU_MCP_SERVER_NAME, FEISHU_MCP_TRANSPORT, FEISHU_TOOL_MAPPINGS, FeishuMcpConnectionState, FeishuMcpSettings, FeishuToolMapping, PROMAX_CONNECTIONS_SETTINGS_NS, PROMAX_FEISHU_MCP_SETTINGS_NS, PlanningAttachmentContext, TaskDeliverableFile, TaskHistoryItem, TaskHistoryStatus, TaskJudgeRepairSnapshot, TaskJudgeRepairState, TaskRunArtifactRegistration, TaskRunCancellationState, TaskRunFileSnapshot, TaskRunJudgeState, apply, beginDispatchPlan, confirmDispatchPlan, controlTaskRunFiles, coordinatorContext, defectFingerprint, defectRequest, dispatchTeamFromRevision, enforceConfirmedDispatchCompleteness, enforceDispatchPlanTool, ensureProjectWorkspace, ensureSessionOutputDirectory, failedWorkMembers, frozenInputMutationReason, inject, installCustomMcpRuntime, installFeishuMcpRuntime, memberToolDenial, memberWorkContext, name, openCompanyProject, prepareDispatchEvidenceInput, prepareTaskAttachmentsForPlanning, prepareTaskSubmission, prepareTaskSubmissionInput, readGeneratedDispatchPlan, readTaskHistory, readTaskRunFiles, recordWorkChild, registerProjectWorkspaces, resolveTaskDeliverableDirectory, saveGeneratedDispatchPlan, saveTaskAttachments, sealTaskRunManifest, taskKeyFromSubmission };