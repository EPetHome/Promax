import { afterEach, expect, it } from "vitest";
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import YAML from "yaml";
import { ContentObjectStore, LocalTrace } from "@promax/promax-report";
import { WorkStore } from "../src/work-store.ts";
import { artifactOperation } from "../src/artifact-operations.ts";
import { enforceDispatchPlanTool } from "../src/index.ts";
import {
  collaborationContext,
  currentNode,
  isReturnIntent,
  nodeState,
  sameDecision,
} from "../../promax-ui-console/src/work-spine.ts";
import {
  parseWorkTurn,
  requirementsDigest,
  type PendingItem,
} from "../../promax-ui-console/src/work-protocol.ts";
import { workRouteFixture } from "../../promax-ui-console/tests/work-route-fixture.ts";
import { scopeSignature } from "../../promax-ui-console/src/work-scope.ts";
import { conditionProgress } from "../../promax-ui-console/src/work-progress.ts";

let f: Awaited<ReturnType<typeof workRouteFixture>>;
afterEach(async () => {
  await f?.close();
});
const contract = {
  artifacts: ["prd.md", "other.md"].map((relativePath) => ({
    relativePath,
    producedBy: "solution_design",
  })),
};
const block = (
  patch: Record<string, unknown> = {},
  intent = "execute",
  deliverables = ["prd.md"],
) =>
  `<promax-work>${JSON.stringify({ intent, card_patch: patch, deliverables, edit_request: null })}</promax-work>`;
const q: PendingItem = {
  id: "merge",
  question: "D1/D2按什么口径归并？",
  decision_key: "merge-policy",
  artifact: "prd.md",
  location: "归并口径",
  options: ["保持独立", "合并同类"],
  effect: "更新归并口径说明",
  source: "ai",
};
async function setup() {
  f = await workRouteFixture();
  const works = new WorkStore(f.scope.projectPath);
  let card = await works.create({
    session_id: "session-one",
    project_id: "local:test",
    title: "需求整理",
    shortname: "需求整理",
  });
  await works.employeeMessage(
    card.work_key,
    "盘点、归并与排序需求，交付可评审清单",
    [],
  );
  await works.propose(
    card.work_key,
    block({ goal: "形成可评审清单", pending: [q] }),
    1,
    contract,
  );
  const objects = new ContentObjectStore(f.scope.projectPath);
  await mkdir(join(f.scope.projectPath, ".任务/baseline/产物快照"), {
    recursive: true,
  });
  await writeFile(
    join(f.scope.projectPath, ".任务/baseline/产物快照/prd.md"),
    "# 需求清单\n## 归并口径\nD1/D2 口径待定。\n## 排序\n保留输入顺序。\n",
  );
  const entry = objects.commit(
    "baseline",
    new LocalTrace(f.scope.projectPath, card.session_id, "unit-test").id,
    [".任务/baseline/产物快照/prd.md"],
    { workKey: card.work_key, kind: "ai_run", author: "personal" },
  )[0]!;
  await works.progress(card.work_key, "草稿已保存", {
    "prd.md": entry.current_sha256,
  });
  card = await works.read(card.work_key);
  // Prior releases stored these gate nodes. Keep exercising their data compatibility without generating them for new work.
  card.spine!.nodes = [
    { id: "understand", title: "明确目标与材料", completion: "核对目标与材料", filenames: [], gate: "employee" },
    ...card.spine!.nodes,
    { id: "delivery", title: "核对与交付", completion: "检查与采纳", filenames: ["prd.md"], gate: "accepted_artifacts" },
  ];
  await writeFile(join(f.scope.projectPath, ".工作", card.work_key, "工作卡.yml"), YAML.stringify(card));
  return { works, card, objects, base: entry.current_sha256 };
}
async function json(path: string, body: Record<string, unknown>) {
  const response = await f.request(path, body);
  const result = await response.json();
  expect(response.status, JSON.stringify(result)).toBe(200);
  return result;
}

it("confirms only the viewed scope revision, persists merge history through the existing route, and never starts execution", async () => {
  f = await workRouteFixture();
  const works = new WorkStore(f.scope.projectPath);
  let card = await works.create({ session_id: "session-one", project_id: "local:test", title: "范围迁移", shortname: "范围迁移" });
  await works.employeeMessage(card.work_key, "讨论范围迁移，先不执行", []);
  const nodes = ["a", "b"].map((id) => ({ id, title: id, completion: "原条件", gate: "employee", filenames: [], conditions: [{ id: "rule", title: `${id}规则`, completion: `${id}核对依据`, kind: "manual", filenames: [] }] }));
  await works.propose(card.work_key, block({ nodes }, "guide", []), 1, contract);
  // Historical conditions are a stored-data fixture; new model suggestions no longer create manual gates.
  card = await works.read(card.work_key);
  await writeFile(join(f.scope.projectPath, ".工作", card.work_key, "工作卡.yml"), YAML.stringify({ ...card, spine: { nodes } }));
  const patch = { nodes: [nodes[1]], scope_change_reason: "合并两个主题", scope_moves: [{ node_id: "a", action: "merge", target_node_id: "b", reason: "条件全部保留" }] };
  await works.propose(card.work_key, block(patch, "guide", []), 2, contract);
  card = await works.read(card.work_key);
  const expected = scopeSignature(card);
  await works.propose(card.work_key, block({ ...patch, scope_change_reason: "修改后的合并原因" }, "guide", []), 3, contract);
  await expect(works.interact(card.work_key, { scope_decision: "accept", scope_expected: expected })).rejects.toThrow("已有变化");
  card = await works.read(card.work_key);
  expect(card.scope_history).toBeUndefined();
  expect(card.spine!.nodes).toHaveLength(2);
  await json("work/card/update", { work_key: card.work_key, action: "interact", scope_decision: "accept", scope_expected: scopeSignature(card), scope_moves: patch.scope_moves });
  const restored = await new WorkStore(f.scope.projectPath).read(card.work_key);
  expect(restored.spine!.nodes).toHaveLength(1);
  expect(restored.spine!.nodes[0]!.conditions).toHaveLength(2);
  expect(restored.scope_history![0]).toMatchObject({ decision: "accept", reason: "修改后的合并原因", unmet: ["a / a规则", "b / b规则"] });
  expect((await works.round(card.work_key))?.task_key).toBeUndefined();
});

it("keeps Q&A lightweight, accepts variable business nodes and rejects model-supplied completion", async () => {
  f = await workRouteFixture();
  const works = new WorkStore(f.scope.projectPath);
  const card = await works.create({
    session_id: "session-one",
    project_id: "local:test",
    title: "问答",
    shortname: "问答",
  });
  await works.employeeMessage(card.work_key, "什么是需求优先级", []);
  await works.propose(card.work_key, block({}, "answer", []), 1, contract);
  expect((await works.read(card.work_key)).spine).toBeUndefined();
  expect((await works.round(card.work_key))?.task_key).toBeUndefined();
  const nodes = ["分析证据", "整理成果"].map((title, i) => ({
    id: `n${i}`,
    title,
    completion: "核对证据",
    gate: "employee",
    filenames: [],
    evidence: { at: "fake" },
  }));
  const turn = parseWorkTurn(block({ nodes }, "guide", []), contract);
  expect(turn.card_patch.nodes).toHaveLength(2);
  expect(turn.card_patch.nodes?.[0]).not.toHaveProperty("evidence");
  expect(
    parseWorkTurn(
      block({ nodes: [{ ...nodes[0], title: "Judge第1轮" }] }),
      contract,
    ).card_patch.nodes,
  ).toBeUndefined();
});

it("persists navigation, node drafts and deferred issues without touching an active run; scope changes require a decision", async () => {
  const { works, card } = await setup();
  const originalNodes = card.spine!.nodes.map((n) => n.title);
  const node = card.pending[0]!.node_id!;
  const round = (await works.round(card.work_key))!;
  await works.writeRound(card.work_key, {
    ...round,
    source: "click",
    task_key: "already-running",
    phase: "checking",
    allowed_members: ["quality_judge"],
  });
  const before = await works.round(card.work_key);
  await json("work/card/update", {
    work_key: card.work_key,
    action: "interact",
    navigation: { mode: "question", node_id: node, question_id: "merge" },
    drafts: {
      [`composer:${node}`]: "未发完的意见",
      "answer:merge": "我还在想",
    },
  });
  let read = await new WorkStore(f.scope.projectPath).read(card.work_key);
  expect(collaborationContext(read)).toContain("以员工最新聊天为准");
  expect(collaborationContext(read)).not.toContain("只围绕此问题讨论");
  await json("work/card/update", {
    work_key: card.work_key,
    action: "message",
    text: "回到主线吧",
  });
  read = await new WorkStore(f.scope.projectPath).read(card.work_key);
  expect(read.navigation?.mode).toBe("overview");
  expect(read.drafts?.["answer:merge"]).toBe("我还在想");
  expect(read.pending).toHaveLength(1);
  expect(read.confirmed).toHaveLength(0);
  expect(await works.round(card.work_key)).toEqual(before);
  expect(collaborationContext(read)).toContain("实际进展");
  await works.interact(card.work_key, { defer_question: "merge" });
  expect((await works.read(card.work_key)).pending[0]!.timing).toBe("later");
  expect(
    (await works.read(card.work_key)).spine!.nodes.map((n) => n.title),
  ).toEqual(originalNodes);
  await works.writeRound(card.work_key, { ...round, phase: "ended" });
  await works.employeeMessage(card.work_key, "也许还要原型", []);
  await works.propose(
    card.work_key,
    block(
      {
        goal: "做完整原型",
        scope_change_reason: "新增方案设计范围",
        pending: [],
      },
      "execute",
      ["other.md"],
    ),
    2,
    contract,
  );
  read = await works.read(card.work_key);
  expect(read.goal).toBe(card.goal);
  expect(read.deliverables.map((d) => d.filename)).toEqual(["prd.md"]);
  expect(read.spine!.nodes.map((n) => n.title)).toEqual(originalNodes);
  expect(read.pending).toHaveLength(1);
  expect(read.scope_proposal?.reason).toContain("新增");
  expect((await works.round(card.work_key))!.turn.intent).toBe("guide");
  await works.interact(card.work_key, { scope_decision: "accept" });
  expect((await works.read(card.work_key)).goal).toBe("做完整原型");
  expect(
    (await works.read(card.work_key)).spine?.nodes.every((n) => n.needs_update),
  ).toBe(true);
});

it("merges compatible multi-source decisions, keeps conflicts, and only reopens answered items with a new circumstance", async () => {
  const { works, card } = await setup();
  await works.addCheckPending(card.work_key, [
    { ...q, id: "judge-copy", source: "check", basis: "独立检查的原文依据" },
  ]);
  let read = await works.read(card.work_key);
  expect(read.pending).toHaveLength(1);
  expect(read.pending[0]!.sources?.map((s) => s.source)).toEqual([
    "ai",
    "check",
  ]);
  expect(sameDecision(q, { ...q, options: ["必须合并", "全部删除"] })).toBe(
    false,
  );
  expect(sameDecision(q, { ...q, artifact: "other.md" })).toBe(false);
  expect(
    sameDecision(
      { ...q, decision_key: "" },
      { ...q, decision_key: "", question: "D1/D3按什么口径归并？" },
    ),
  ).toBe(false);
  read = await works.update(
    card.work_key,
    { answer: { id: "merge", text: "保持独立" } },
    read.updated_at,
  );
  await works.addCheckPending(card.work_key, [
    { ...q, id: "later-check", source: "check" },
  ]);
  expect((await works.read(card.work_key)).pending).toEqual([]);
  await works.addCheckPending(card.work_key, [
    {
      ...q,
      id: "new-context",
      source: "check",
      reopen_reason: "新材料表明D1/D2同属一条需求",
      reviewed_sha256: "b".repeat(64),
    },
  ]);
  read = await works.read(card.work_key);
  expect(read.pending).toHaveLength(1);
  expect(read.pending[0]!.reopen_reason).toContain("新材料");
  expect(read.decisions).toHaveLength(1);
});

it("records a decision, authorizes only its edit, publishes new bytes, checks that version and restores the same spine", async () => {
  const { works, card, objects, base } = await setup();
  const verified = await works.interact(card.work_key, {
    confirm_node: card.spine!.nodes[0]!.id,
  });
  const result = await json("work/card/update", {
    action: "decide",
    work_key: card.work_key,
    id: "merge",
    text: "保持独立",
    base_sha256: base,
    base_updated_at: verified.updated_at,
  });
  expect(result.ready).toBe(true);
  let round = (await works.round(card.work_key))!;
  expect(round.turn.edit_request).toMatchObject({
    filename: "prd.md",
    base_sha256: base,
    anchor: { type: "heading", value: "归并口径" },
  });
  expect((await works.read(card.work_key)).decisions?.[0]).toMatchObject({
    state: "awaiting_start",
    base_sha256: base,
  });
  await json("work/card/update", {
    action: "start",
    work_key: card.work_key,
    revision: round.revision,
    source: "click",
  });
  round = (await works.round(card.work_key))!;
  expect(round).toMatchObject({ protocol: 2, execution_version: (await works.read(card.work_key)).requirement_version });
  const events: Array<Record<string, unknown>> = [
    {
      type: "tool/call",
      seq: 5,
      data: { name: "solution_design", callId: "edit" },
    },
    {
      type: "tool/result",
      seq: 6,
      data: {
        message: {
          content: [
            { type: "tool-result", toolCallId: "edit", isError: false },
          ],
        },
      },
    },
  ];
  const main = { id: card.session_id, cwd: f.scope.projectPath };
  const payload = {
    agent: {
      session: {
        header: main,
        events,
      },
      steer() {},
    },
    turn: 1,
    signal: new AbortController().signal,
  };
  // The member session is bound by the program from the actual dispatch result, then settles.
  const child = (id: string) => ({ session: { header: { id, cwd: f.scope.projectPath, origin: "subagent", parentSession: card.session_id }, events: [] } });
  const dispatch = async (name: string, childId: string) => {
    await f.hooks.get("tools/post-execute")!({ name, agent: payload.agent }, { isError: false, value: { kind: "continuable", subagentId: childId } }, async () => ({}));
    f.hooks.get("subagent/end")!({ id: childId });
  };
  await dispatch("solution_design", "member-1");
  const content =
    "# 需求清单\n## 归并口径\nD1/D2 保持独立。\n## 排序\n保留输入顺序。\n";
  await writeFile(
    join(f.scope.projectPath, ".任务", round.task_key!, "产物快照/prd.md"),
    content,
  );
  // Without an accepted receipt the draft never advances to checking.
  await f.hooks.get("agent/turn-stopping")!(payload);
  expect((await works.round(card.work_key))!.phase).toBe("generating");
  const receipt = { filename: "prd.md", status: "draft_ready", summary: "归并口径改为保持独立", unverified: [], gaps: [], input_version: round.execution_version };
  expect((await f.submit("promax_member_receipt", { ...receipt, input_version: 999 }, { callId: "r-bad", agent: child("member-1") })).isError).toBe(true);
  expect((await f.submit("promax_member_receipt", receipt, { callId: "r-1", agent: child("member-1") })).isError).toBe(false);
  const acceptedRound = await works.round(card.work_key);
  expect((await f.submit("promax_member_receipt", receipt, { callId: "r-2", agent: child("member-1") })).value).toMatchObject({ recorded: true });
  // Stage only validates; the authoritative commit must not submit or rewrite the round a second time.
  expect(await works.round(card.work_key)).toEqual(acceptedRound);
  events.push({ type: "assistant/message", seq: 7, data: { message: { content: [] } } });
  await f.hooks.get("agent/turn-stopping")!(payload);
  round = (await works.round(card.work_key))!;
  expect(round.phase).toBe("checking");
  expect((await works.read(card.work_key)).decisions?.[0]!.state).toBe(
    "checking",
  );
  await works.interact(card.work_key, { navigation: { mode: "overview" } });
  events.push({
    type: "tool/call",
    seq: 10,
    data: { name: "quality_judge", callId: "check" },
  });
  await dispatch("quality_judge", "judge-1");
  // Judge writes are refused in the structured protocol; the result is submitted as data.
  expect(await enforceDispatchPlanTool(f.root, { name: "write", arguments: { path: `.任务/${round.task_key}/判定-r1.md` }, agent: child("judge-1") }, async () => "allow")).toMatchObject({ kind: "deny" });
  const judgment = { verdict: "PASS", unverified: [], decisions: [], input_version: round.execution_version, review_request: round.review_request,
    acceptance: { baseline_version: round.acceptance_baseline!.version, items: round.acceptance_scope!.map(id => ({ id, state: "met", evidence: "隔离输入核对，非真实Judge语义验收" })) } };
  expect((await f.submit("promax_check_result", { ...judgment, issues: [{ id: "I1", severity: "low", artifact: "prd.md", location: "排序", evidence: "e", impact: "i", fix: "f" }] }, { callId: "c-bad", agent: child("judge-1") })).isError).toBe(true);
  const checkedResult = await f.submit("promax_check_result", { ...judgment, issues: [] }, { callId: "c-1", agent: child("judge-1") });
  expect(checkedResult.isError, String(checkedResult.value)).toBe(false);
  events.push({ type: "assistant/message", seq: 11, data: { message: { content: [] } } });
  await f.hooks.get("agent/turn-stopping")!(payload);
  const restored = await new WorkStore(f.scope.projectPath).read(card.work_key);
  const versions = objects.versions(card.work_key, "prd.md");
  expect(versions).toHaveLength(2);
  expect(restored.decisions?.[0]).toMatchObject({
    state: "applied",
    applied_sha256: versions[1]!.sha256,
    task_key: round.task_key,
  });
  expect(restored.confirmed[0]!.text).toContain("保持独立");
  expect(restored.navigation?.mode).toBe("overview");
  expect(objects.readVersion(card.work_key, "prd.md", base).content).toContain(
    "口径待定",
  );
  expect(
    objects.readVersion(card.work_key, "prd.md", versions[1]!.sha256).content,
  ).toBe(content);
  const checked = (await artifactOperation(
    f.scope.projectPath,
    "versions",
    { work_key: card.work_key, filename: "prd.md" },
    "personal",
  )) as { check: { outcome: { state: string } } };
  expect(checked.check.outcome.state).toBe("passed");
  expect(nodeState(restored, restored.spine!.nodes[0]!)).toBe("done"); // A local decision cannot regress an unaffected, explicitly verified intake node.
  expect(currentNode(await works.read(card.work_key))?.gate).toBe(
    "checked_artifacts",
  ); // Judge PASS alone must not close a production node before employee review.
  const prior = await works.read(card.work_key);
  await works.update(
    card.work_key,
    { confirmed_text: "新增范围要求" },
    prior.updated_at,
  );
  const stale = (await artifactOperation(
    f.scope.projectPath,
    "versions",
    { work_key: card.work_key, filename: "prd.md" },
    "personal",
  )) as { check: { error: string } };
  expect(stale.check.error).toContain("要求已变化");
});

it("keeps a decision and existing artifact when the target is missing; unrelated completion cannot apply it", async () => {
  const { works, card, objects, base } = await setup();
  const item = {
    ...q,
    id: "missing",
    decision_key: "another",
    location: "不存在的章节",
  };
  await works.addCheckPending(card.work_key, [item]);
  const read = await works.read(card.work_key);
  const result = await json("work/card/update", {
    action: "decide",
    work_key: card.work_key,
    id: item.id,
    text: "合并同类",
    base_updated_at: read.updated_at,
  });
  expect(result.ready).toBe(false);
  expect(result.gap).toContain("锚点");
  // A missing target is not a dead end: the decision stays effective and goes to the coordinator for impact analysis.
  expect(result.needs_context).toBe(true);
  expect(objects.versions(card.work_key, "prd.md")).toHaveLength(1);
  expect(objects.versions(card.work_key, "prd.md")[0]!.sha256).toBe(base);
  await works.finishDecisions(
    card.work_key,
    {
      ...(await works.round(card.work_key))!,
      decision_ids: [],
      phase: "ended",
    },
    true,
    "其他执行完成",
  );
  expect((await works.read(card.work_key)).decisions?.[0]).toMatchObject({
    state: "processing",
    note: expect.stringContaining("锚点"),
  });
  expect(isReturnIntent("请收回主线")).toBe(true);
  expect(isReturnIntent("不要收回主线，我想继续展开")).toBe(false);
  expect(requirementsDigest(await works.read(card.work_key))).toContain(
    "合并同类",
  );
});

it("keeps the decision but refuses to apply it against a version the employee has not seen", async () => {
  const { works, card, objects, base } = await setup();
  const current = objects.saveHumanEdit({
    work_key: card.work_key,
    filename: "prd.md",
    base_sha256: base,
    content: "# 需求清单\n## 归并口径\n另一位员工的新修改",
    author: "personal",
  });
  const result = await json("work/card/update", {
    action: "decide",
    work_key: card.work_key,
    id: "merge",
    text: "保持独立",
    base_sha256: base,
    base_updated_at: card.updated_at,
  });
  expect(result.ready).toBe(false);
  expect(result.gap).toContain("成果版本已变化");
  expect((await works.read(card.work_key)).decisions?.[0]).toMatchObject({ state: "processing", note: expect.stringContaining("成果版本已变化") });
  expect(objects.versions(card.work_key, "prd.md")).toHaveLength(2);
  expect(objects.versions(card.work_key, "prd.md").at(-1)!.sha256).toBe(
    current.current_sha256,
  );
});

it("counts explicit conditions only; a PASS needs version-bound employee review before artifact conditions close", async () => {
  const { works, card, base } = await setup();
  const nodes = [{ id: "rules", title: "明确规则", completion: "完成本次规则", gate: "accepted_artifacts", filenames: ["prd.md"], conditions: [
    { id: "document", title: "规则已落实到成果", completion: "原文包含要求且无已知冲突", kind: "artifact", filenames: ["prd.md"], blocking: true, evidence: { basis: "fake" } },
    { id: "limit", title: "人数上限明确", completion: "员工给出上限依据", kind: "manual", filenames: [], blocking: false },
  ] }];
  await works.propose(card.work_key, block({ nodes, scope_change_reason: "拆清完成条件" }), 2, contract);
  // New explicit structure cannot delete existing incomplete nodes.
  await expect(works.interact(card.work_key, { scope_decision: "accept" })).rejects.toThrow("未完成节点");
  const kept = card.spine!.nodes.map((n) => ({ ...n, ...(n.gate === "checked_artifacts" ? { conditions: nodes[0]!.conditions } : {}) }));
  await works.propose(card.work_key, block({ nodes: kept, scope_change_reason: "为原节点补充可判定条件" }), 3, contract);
  let current = await works.interact(card.work_key, { scope_decision: "accept", defer_question: "merge" });
  const node = current.spine!.nodes.find((n) => n.conditions?.length)!;
  expect(node.conditions![0]).not.toHaveProperty("evidence");
  expect(conditionProgress(current, node)).toMatchObject({ total: 2, satisfied: 0, blocking: "剩余项阻断下一步" });
  const report = ".任务/baseline/判定-r1.md";
  await writeFile(join(f.scope.projectPath, report), `---\n${YAML.stringify({ reviewer: "quality_judge", round: 1, verdict: "PASS", scope: "规则", reviewed_artifacts: [{ filename: "prd.md", sha256: base }], issues: [], unverified: [], decisions: [] })}---\n`);
  await works.writeRound(card.work_key, { ...(await works.round(card.work_key))!, phase: "ended", last_check: { report, judge_round: 1, reviewed_hashes: { "prd.md": base }, requirements_digest: requirementsDigest(current) } });
  await works.progress(card.work_key, "检查完成");
  current = await works.read(card.work_key);
  expect(conditionProgress(current, current.spine!.nodes.find((n) => n.id === node.id)!)).toMatchObject({ satisfied: 0 });
  current = await works.accept(card.work_key, "prd.md", base, [`${node.id}/document`], "test-reviewer");
  expect(conditionProgress(current, current.spine!.nodes.find((n) => n.id === node.id)!)).toMatchObject({ satisfied: 1, blocking: "剩余项不阻断下一步" });
  expect(current.acceptances?.at(-1)).toMatchObject({ author: "test-reviewer", sha256: base });
  expect(nodeState(current, current.spine!.nodes.find((n) => n.id === node.id)!)).not.toBe("done");
  current = await works.interact(card.work_key, { confirm_condition: { node_id: node.id, condition_id: "limit", basis: "员工已核对当前范围内不限制人数" } });
  expect(nodeState(current, current.spine!.nodes.find((n) => n.id === node.id)!)).toBe("done");
  expect(conditionProgress(current, current.spine!.nodes[0]!).label).toBe("条件待明确");
  await works.update(card.work_key, { confirmed_text: "新要求：必须提供失败示例" }, current.updated_at);
  const changed = await artifactOperation(f.scope.projectPath, "versions", { work_key: card.work_key, filename: "prd.md" }, "test-reviewer") as { accepted: boolean };
  expect(changed.accepted).toBe(false); // Same bytes reviewed under old requirements are not current acceptance.
});

it("feedback reopens affected nodes, keeps original evidence and distinguishes a claim from a confirmed defect", async () => {
  const { works, card, base } = await setup();
  const node = card.spine!.nodes.find((n) => n.gate === "checked_artifacts")!;
  const originalRound = await works.round(card.work_key);
  let current = await works.interact(card.work_key, { feedback: { node_id: node.id, artifact: "prd.md", kind: "defect", text: "规则与原要求矛盾，请核对" } });
  const feedback = current.feedback![0]!;
  expect(feedback).toMatchObject({ state: "pending", hashes: { "prd.md": base } });
  expect(nodeState(current, current.spine!.nodes.find((n) => n.id === node.id)!)).toBe("stale");
  current = await works.interact(card.work_key, { review_feedback: { id: feedback.id, state: "confirmed", basis: "对照原始要求第二条与规则原文，冲突成立" } });
  expect(nodeState(current, current.spine!.nodes.find((n) => n.id === node.id)!)).toBe("blocked");
  await expect(works.interact(card.work_key, { review_feedback: { id: feedback.id, state: "resolved", basis: "口头说已修复" } })).rejects.toThrow("已检查的新版本");
  expect(await works.round(card.work_key)).toEqual(originalRound);
  expect(current.pending).toHaveLength(1);
});

it("persists deduplicated open item Tabs and browsing location separately from progress and unsubmitted input", async () => {
  const { works, card } = await setup();
  const before = await works.round(card.work_key);
  await works.interact(card.work_key, { navigation: { mode: "question", question_id: "merge", opened_question_ids: ["merge", "merge"] }, drafts: { "composer:question:merge": "事项自己的讨论草稿" } });
  const current = await works.interact(card.work_key, { navigation: { mode: "overview", located_node_id: card.spine!.nodes[0]!.id } });
  expect(current.navigation?.opened_question_ids).toEqual(["merge"]);
  expect(current.navigation?.located_node_id).toBe(card.spine!.nodes[0]!.id);
  expect(current.navigation?.node_id).toBeUndefined();
  expect(current.drafts?.["composer:question:merge"]).toBe("事项自己的讨论草稿");
  expect(await works.round(card.work_key)).toEqual(before);
});
