评分与反馈简报

## 原始任务
请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。

包括：
1. 评分分布与数据质量；
2. 主要反馈，附少量原文及对应 record_id；
3. 三条有依据的建议，需要进一步验证的明确标注；
4. 材料限制。

评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。

仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。

## 有效要求（程序绑定；优先于主 Agent 的 prompt/message/focus 与工作计划）
来源优先级：系统权限与产品最低规则不可由计划覆盖；用户原始要求及有效决定决定目标，解释/假设不是用户决定。改变用途、证据要求或交付范围须走有效决定/范围变更；执行后接受局限不追溯改写。
用户原始依据：[{"id":"origin","kind":"user_request","text":"请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。\n\n包括：\n1. 评分分布与数据质量；\n2. 主要反馈，附少量原文及对应 record_id；\n3. 三条有依据的建议，需要进一步验证的明确标注；\n4. 材料限制。\n\n评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。\n\n仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。","at":"2026-09-25T15:24:08.312Z"},{"id":"event:5094d8fc-fa77-4155-8062-f8a55c89475b","kind":"user_request","text":"附件是新版评分数据，请完整替代上一版，不要与旧数据合并。只更新受影响的统计、表述、结论和必要的关联依据，未受影响的内容保持不变；完成必要检查并保存为新版本，保留旧版，并说明这次改了什么。","at":"2026-09-25T15:40:30.088Z","input_version":6}]
真实能力策略（不是用户禁令；配置可用不代表实际调用成功）：{"browser":"disabled","public_web":"authorized_members_only","judge_web":"disabled","availability":"not_probed"}。公开搜索/正文读取与浏览器自动化分开；未配置、调用失败、未尝试须据实际工具结果记录。
产品规则与版本（不是用户原话）：{"revision":"promax-product-team@r11","rules":[{"id":"USER_ANALYSIS_REQUIRED_SECTIONS","text":"按原始用户要求选择交付深度。简洁评分报告只要求评分分布与数据质量、主要反馈及来源举例、3条待验证建议、必要限制与查看入口；不要求固定九节、全量record_id、模板构成、额外趋势数字或长篇真值表。计算与追溯明细由程序结论关联/工具结果入口承载，不手工重复矩阵。完整分析模式仍检查输入与样本/口径、数据质量与清洗、结构化反馈或指标基线、趋势与异常、归因假设与替代解释、反例与冲突、边界真值表、限制与未验证项、证据追溯矩阵；按适用性说明，不编造无依据扩展。","files":["user_analysis.md"],"kind":"user-analysis-report","necessity":"required","evidence_obligation":{"question":"user-analysis-report 类成果的规则 USER_ANALYSIS_REQUIRED_SECTIONS 要求的关键判断，是否在比较/使用场景下由当前版本正文给出可定位依据（按原始用户要求选择交付深度。简洁评分报告只要求评分分布与数据质量、主要反馈及来源举例、3条待验证建议、必要限制与查看入口）","min_basis":"当前成果正文中的可定位依据；外部事实需带来源、时点与口径；用户材料需标来源与适用范围；缺少适用依据则记无法验证，不降低原目标"},"evidence_basis":[],"capability_obligation":["数值口径、分母与可复算输入","样本代表性及可外推范围的说明"]},{"id":"USER_ANALYSIS_NUMBER_TRACE","text":"关键数字、比例、趋势、引文和图表应回到已登记结论关联、SRC-*、输入位置、时间窗、分母与公式；不强制手工E-*矩阵。冻结评分用promax_rating_facts与当前版本程序复算凭证核对，不逐行重数；计算结果不是新的原始事实源。C11 缺失值反例：10 人中仅 6 人提供本周数据，3 人达标；观测样本达标率是 3/6，不能把缺失 4 人当 0 后宣称总体率 3/10，也不能把上月数据合入本周分母。必须写清缺失处理、适用人群与推断边界。","files":["user_analysis.md"],"kind":"user-analysis-report","necessity":"required","evidence_obligation":{"question":"每个关键数值的分子、分母、过滤去重、缺失处理、时间窗与舍入是否声明且可复算","min_basis":"冻结输入或已保存记录中的字段定位与计算规格；口径变化留版本并重算受影响结果"},"evidence_basis":["source_link","numeric_recompute"],"capability_obligation":["数值口径与可复算输入","样本代表性与可外推范围说明"]},{"id":"USER_ANALYSIS_INFERENCE_BOUNDARY","text":"核对评论声量未外推用户总体、相关性未写成因果；提出归因假设时保留替代解释。评分档位共75条只证明档位数，不证明某主题诉求集中；要称集中须有主题频次依据；只作定性举例并明确未统计主题频次时，不强加全量语义分析。数值分类先对照报告原句与同源程序事实：1.5归non_integer、0/6/−1归out_of_range时不得指责为混淆，实际混淆仍应报缺陷。仅在实际任务需要且有阈值依据时核对真值表，不为简洁评分报告新增长表。版本替换不是时间趋势；未知阈值不得自创。","files":["user_analysis.md"],"kind":"user-analysis-report","necessity":"required","evidence_obligation":{"question":"user-analysis-report 类成果的规则 USER_ANALYSIS_INFERENCE_BOUNDARY 要求的关键判断，是否在比较/使用场景下由当前版本正文给出可定位依据（核对评论声量未外推用户总体、相关性未写成因果；提出归因假设时保留替代解释。评分档位共75条只证明档位数，不证明某主题诉求）","min_basis":"当前成果正文中的可定位依据；外部事实需带来源、时点与口径；用户材料需标来源与适用范围；缺少适用依据则记无法验证，不降低原目标"},"evidence_basis":[],"capability_obligation":["数值口径、分母与可复算输入","样本代表性及可外推范围的说明"]}]}
主 Agent 的理解/计划（非权威）："基于本次附件的评分样本，产出一份简洁可读的 Markdown 报告：有效评分口径与分布、数据质量、主要反馈（少量原文+record_id）、三条有依据的建议（含需验证标注）、材料限制。"
未确认假设/建议：["报告只保留 3—5 条代表性原始反馈，不做全量清单，保证可直接阅读。","无效评分单独小计并注明类型构成（数字字符串、布尔值、越界或缺失等），说明其对分布解释的影响。","三条建议只限定在本次附件能支撑的范围内，超出样本的推断统一标注「需进一步验证」。"]
全任务验收基准（必需性不可豁免）：{"protocol":1,"version":"ce4436a24c2f230040bebd636e41962326c605c19e3c251ef5ef9cb8cdaea665","requirement_version":8,"items":[{"id":"R1","text":"范围、用途与原始要求及有效决定一致；主 Agent 新增限制有真实来源；基准未遗漏原始目标。","required":true,"necessity":"required","source_refs":["origin","event:5094d8fc-fa77-4155-8062-f8a55c89475b"],"files":["user_analysis.md"],"source_kind":"user_request","evidence_basis":["requirement_record"],"evidence_obligation":{"question":"本次交付范围与用途是否由用户原始要求/有效决定确定，主 Agent 的限制是否有权限或用户依据","min_basis":"原始要求与有效决定记录；无来源的限制不升级为权威要求；修改用途须走有效决定"},"capability_obligation":["读取原始要求、事件与决定记录","范围变更留版本"]},{"id":"R3","text":"事实、推断、未知及结论强度一致；未尝试/失败/未发现不推导不存在，保留时效与口径限制。","required":true,"necessity":"required","source_refs":["product:effective-requirements/1"],"files":["user_analysis.md"],"source_kind":"product_rule","evidence_obligation":{"question":"每个关键结论的类型（当期事实/比较/变化/趋势/总体/原因）是否有匹配强度的依据，未知是否如实保留","min_basis":"结论类型对应的最低依据；不支持时降级表述并重新核对原目标，不用措辞换取满足率"},"capability_obligation":["按结论类型判断最低依据","保留时点与口径限制"]},{"id":"R4","text":"本次必交成果已保存、可读取；当前版本、引用和依据可追溯。","required":true,"necessity":"required","source_refs":["origin","event:5094d8fc-fa77-4155-8062-f8a55c89475b"],"files":["user_analysis.md"],"source_kind":"product_rule","evidence_basis":["program_check"],"evidence_obligation":{"question":"当前被审版本是否与实际保存的成果字节一致，关键结论能否定位回正文与依据","min_basis":"程序保存的成果哈希、版本与可读入口；结论关联与来源版本一致"},"capability_obligation":["成果哈希与版本绑定","可读入口检查"]},{"id":"D:USER_ANALYSIS_REQUIRED_SECTIONS","text":"按原始用户要求选择交付深度。简洁评分报告只要求评分分布与数据质量、主要反馈及来源举例、3条待验证建议、必要限制与查看入口；不要求固定九节、全量record_id、模板构成、额外趋势数字或长篇真值表。计算与追溯明细由程序结论关联/工具结果入口承载，不手工重复矩阵。完整分析模式仍检查输入与样本/口径、数据质量与清洗、结构化反馈或指标基线、趋势与异常、归因假设与替代解释、反例与冲突、边界真值表、限制与未验证项、证据追溯矩阵；按适用性说明，不编造无依据扩展。","required":true,"necessity":"required","source_refs":["product:promax-product-team@r11:USER_ANALYSIS_REQUIRED_SECTIONS"],"files":["user_analysis.md"],"source_kind":"product_rule","evidence_basis":[],"evidence_obligation":{"question":"user-analysis-report 类成果的规则 USER_ANALYSIS_REQUIRED_SECTIONS 要求的关键判断，是否在比较/使用场景下由当前版本正文给出可定位依据（按原始用户要求选择交付深度。简洁评分报告只要求评分分布与数据质量、主要反馈及来源举例、3条待验证建议、必要限制与查看入口）","min_basis":"当前成果正文中的可定位依据；外部事实需带来源、时点与口径；用户材料需标来源与适用范围；缺少适用依据则记无法验证，不降低原目标"},"capability_obligation":["数值口径、分母与可复算输入","样本代表性及可外推范围的说明"]},{"id":"D:USER_ANALYSIS_NUMBER_TRACE","text":"关键数字、比例、趋势、引文和图表应回到已登记结论关联、SRC-*、输入位置、时间窗、分母与公式；不强制手工E-*矩阵。冻结评分用promax_rating_facts与当前版本程序复算凭证核对，不逐行重数；计算结果不是新的原始事实源。C11 缺失值反例：10 人中仅 6 人提供本周数据，3 人达标；观测样本达标率是 3/6，不能把缺失 4 人当 0 后宣称总体率 3/10，也不能把上月数据合入本周分母。必须写清缺失处理、适用人群与推断边界。","required":true,"necessity":"required","source_refs":["product:promax-product-team@r11:USER_ANALYSIS_NUMBER_TRACE"],"files":["user_analysis.md"],"source_kind":"product_rule","evidence_basis":["source_link","numeric_recompute"],"evidence_obligation":{"question":"每个关键数值的分子、分母、过滤去重、缺失处理、时间窗与舍入是否声明且可复算","min_basis":"冻结输入或已保存记录中的字段定位与计算规格；口径变化留版本并重算受影响结果"},"capability_obligation":["数值口径与可复算输入","样本代表性与可外推范围说明"]},{"id":"D:USER_ANALYSIS_INFERENCE_BOUNDARY","text":"核对评论声量未外推用户总体、相关性未写成因果；提出归因假设时保留替代解释。评分档位共75条只证明档位数，不证明某主题诉求集中；要称集中须有主题频次依据；只作定性举例并明确未统计主题频次时，不强加全量语义分析。数值分类先对照报告原句与同源程序事实：1.5归non_integer、0/6/−1归out_of_range时不得指责为混淆，实际混淆仍应报缺陷。仅在实际任务需要且有阈值依据时核对真值表，不为简洁评分报告新增长表。版本替换不是时间趋势；未知阈值不得自创。","required":true,"necessity":"required","source_refs":["product:promax-product-team@r11:USER_ANALYSIS_INFERENCE_BOUNDARY"],"files":["user_analysis.md"],"source_kind":"product_rule","evidence_basis":[],"evidence_obligation":{"question":"user-analysis-report 类成果的规则 USER_ANALYSIS_INFERENCE_BOUNDARY 要求的关键判断，是否在比较/使用场景下由当前版本正文给出可定位依据（核对评论声量未外推用户总体、相关性未写成因果；提出归因假设时保留替代解释。评分档位共75条只证明档位数，不证明某主题诉求）","min_basis":"当前成果正文中的可定位依据；外部事实需带来源、时点与口径；用户材料需标来源与适用范围；缺少适用依据则记无法验证，不降低原目标"},"capability_obligation":["数值口径、分母与可复算输入","样本代表性及可外推范围的说明"]}],"files":["user_analysis.md"]}
本次须逐项回报的 scope IDs：["R1","R3","R4","D:USER_ANALYSIS_REQUIRED_SECTIONS","D:USER_ANALYSIS_NUMBER_TRACE","D:USER_ANALYSIS_INFERENCE_BOUNDARY"]。scope 外不默认为满足。
## 主 Agent 理解的当前目标（不是用户原话）
基于本次附件的评分样本，产出一份简洁可读的 Markdown 报告：有效评分口径与分布、数据质量、主要反馈（少量原文+record_id）、三条有依据的建议（含需验证标注）、材料限制。

## 本轮最新输入（增量，不替代原始任务）
按刚才确认的范围开始做。

## 员工明确要求
- 请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。

包括：
1. 评分分布与数据质量；
2. 主要反馈，附少量原文及对应 record_id；
3. 三条有依据的建议，需要进一步验证的明确标注；
4. 材料限制。

评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。

仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。
- 请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。

包括：
1. 评分分布与数据质量；
2. 主要反馈，附少量原文及对应 record_id；
3. 三条有依据的建议，需要进一步验证的明确标注；
4. 材料限制。

评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。

仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。
- 请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。

包括：
1. 评分分布与数据质量；
2. 主要反馈，附少量原文及对应 record_id；
3. 三条有依据的建议，需要进一步验证的明确标注；
4. 材料限制。

评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。

仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。
- 请分析附件中的评分与反馈，交付一份简洁、可直接阅读的 Markdown 报告。

包括：
1. 评分分布与数据质量；
2. 主要反馈，附少量原文及对应 record_id；
3. 三条有依据的建议，需要进一步验证的明确标注；
4. 材料限制。

评分口径：只接受原始数值类型的1—5整数；数字字符串、布尔值及其他非法评分不计入有效评分。比例以有效评分为分母，不去重，不按日期过滤。

仅使用本次附件，不联网、不扩展为市场调研。完成必要检查并保存正式版本；如果只有草稿、保存失败或结果未知，请明确说明真实状态。

## 员工决定（当前有效）

## 已采纳建议（计划口径，不代表已经执行，例如访谈尚未实际进行）

## 尚待员工决定（不得写成已确认）

## 选用材料（原文见输入清单中程序编号的来源，摘要不是独立来源）
- Promax实测-评分样本-v1.json
- Promax实测-评分样本-v2.json

## 续接位置
- 需求版本 8
- 已有成果版本 8d55cc5a（已保存 · 部分完成）
相关成果 user_analysis.md
